import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { BookingService } from '../../services/booking.service';
import { AuthService } from '../../services/auth.service';
import { I18nService } from '../../services/i18n.service';
import { NotificationService } from '../../services/notification.service';
import { Booking } from '../../models/booking.model';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  imports: [CommonModule, RouterLink, TranslatePipe],
  templateUrl: './my-bookings.component.html',
  styleUrl: './my-bookings.component.css'
})
export class MyBookingsComponent implements OnInit {
  bookings = signal<Booking[]>([]);

  // Cancellation Modal state
  selectedBookingForCancel: Booking | null = null;
  estimatedRefund = 0;

  constructor(
    public bookingService: BookingService,
    public authService: AuthService,
    public i18nService: I18nService,
    private notificationService: NotificationService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadUserBookings();
  }

  loadUserBookings(): void {
    const user = this.authService.currentUser();
    if (user) {
      const list = this.bookingService.getUserBookings(user.id, user.email);
      this.bookings.set(list);
    } else {
      this.bookings.set([]);
    }
  }

  openCancelModal(booking: Booking): void {
    if (booking.status === 'CANCELLED') {
      this.notificationService.info('This reservation has already been cancelled.');
      return;
    }

    this.selectedBookingForCancel = booking;
    // Calculate refund: Total Fare - (₹120 * passengerCount)
    const cancelCharge = 120 * booking.passengers.length;
    this.estimatedRefund = Math.max(0, booking.fareBreakdown.totalFare - cancelCharge);
  }

  closeCancelModal(): void {
    this.selectedBookingForCancel = null;
    this.estimatedRefund = 0;
  }

  confirmCancellation(): void {
    if (!this.selectedBookingForCancel) return;

    const result = this.bookingService.cancelBooking(this.selectedBookingForCancel.id);
    if (result.success) {
      this.loadUserBookings();
      this.closeCancelModal();
    } else {
      this.notificationService.error(result.message);
    }
  }

  printTicket(): void {
    window.print();
  }
}
