export interface Station {
  code: string;
  name: string;
  city: string;
  state: string;
}

export interface TrainClass {
  code: 'SL' | '3A' | '2A' | '1A';
  name: string;
  baseFare: number;
  availableSeats: number;
  status: 'AVAILABLE' | 'RAC' | 'WL';
  statusNumber?: number; // e.g. 42 for Available, 12 for RAC, 8 for WL
  coachCodePrefix: string; // e.g. 'S', 'B', 'A', 'H'
  perks: string[];
}

export interface Train {
  id: string;
  trainNumber: string;
  trainName: string;
  trainType: 'Vande Bharat' | 'Rajdhani Superfast' | 'Tejas Express' | 'Shatabdi Express' | 'Deccan Odyssey' | 'Superfast Express' | 'Duronto Superfast' | 'Garib Rath' | 'Jan Shatabdi' | 'Express Special' | string;
  fromStation: Station;
  toStation: Station;
  departureTime: string; // "06:00 AM"
  arrivalTime: string;   // "02:15 PM"
  duration: string;      // "8h 15m"
  runsOn: string[];      // ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  distanceKm: number;
  classes: TrainClass[];
  rating: number;
  foodIncluded: boolean;
  haltsCount: number;
  highlight: string;
}
