import { Injectable, signal } from '@angular/core';
import { User, AuthSession } from '../models/user.model';
import { NotificationService } from './notification.service';
import { I18nService } from './i18n.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly USERS_KEY = 'lumarail_users';
  private readonly SESSION_KEY = 'lumarail_session';

  // Reactive state for logged in user
  currentUser = signal<User | null>(this.getStoredSessionUser());

  constructor(
    private notificationService: NotificationService,
    private i18nService: I18nService
  ) {
    this.seedDefaultUsers();
  }

  private seedDefaultUsers(): void {
    const demoUsers: User[] = [
      {
        id: 'usr_demo_101',
        name: 'Vikramaditya Roy (Student)',
        email: 'student@lumarail.com',
        phone: '9876543210',
        password: 'password123',
        createdAt: '2026-01-01T00:00:00.000Z'
      },
      {
        id: 'usr_demo_102',
        name: 'Ananya Sharma',
        email: 'ananya@lumarail.com',
        phone: '9123456789',
        password: 'password123',
        createdAt: '2026-01-01T00:00:00.000Z'
      },
      {
        id: 'usr_demo_103',
        name: 'Academic Evaluator',
        email: 'evaluator@lumarail.com',
        phone: '9888877777',
        password: 'password123',
        createdAt: '2026-01-01T00:00:00.000Z'
      },
      {
        id: 'usr_demo_104',
        name: 'Demo Student (AuraRail Legacy)',
        email: 'student@aurarail.com',
        phone: '9876543210',
        password: 'password123',
        createdAt: '2026-01-01T00:00:00.000Z'
      }
    ];

    try {
      const existingStr = localStorage.getItem(this.USERS_KEY);
      const existing: User[] = existingStr ? JSON.parse(existingStr) : [];
      
      demoUsers.forEach(du => {
        const idx = existing.findIndex(u => u.email.toLowerCase() === du.email.toLowerCase());
        if (idx === -1) {
          existing.push(du);
        } else {
          existing[idx].password = du.password;
        }
      });
      localStorage.setItem(this.USERS_KEY, JSON.stringify(existing));
    } catch {
      localStorage.setItem(this.USERS_KEY, JSON.stringify(demoUsers));
    }
  }

  private getAllUsers(): User[] {
    try {
      const data = localStorage.getItem(this.USERS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  private getStoredSessionUser(): User | null {
    try {
      const sessionData = localStorage.getItem(this.SESSION_KEY);
      if (sessionData) {
        const session: AuthSession = JSON.parse(sessionData);
        return session.user;
      }
    } catch {
      // Session parsing error
    }
    return null;
  }

  isLoggedIn(): boolean {
    return this.currentUser() !== null;
  }

  register(userData: { name: string; email: string; phone: string; password: string }): { success: boolean; message: string } {
    const users = this.getAllUsers();
    const normalizedEmail = userData.email.trim().toLowerCase();

    if (users.some(u => u.email.toLowerCase() === normalizedEmail)) {
      return { success: false, message: this.i18nService.translate('auth.user_exists') };
    }

    const newUser: User = {
      id: 'usr_' + Date.now().toString(36),
      name: userData.name.trim(),
      email: normalizedEmail,
      phone: userData.phone.trim(),
      password: userData.password,
      createdAt: new Date().toISOString()
    };

    users.push(newUser);
    localStorage.setItem(this.USERS_KEY, JSON.stringify(users));

    this.createSession(newUser);
    this.notificationService.success(this.i18nService.translate('auth.reg_success'), 'Welcome!');
    return { success: true, message: 'Registration successful' };
  }

  login(email: string, password: string): { success: boolean; message: string } {
    const users = this.getAllUsers();
    const normalizedEmail = email.trim().toLowerCase();

    let matchedUser = users.find(u => u.email.toLowerCase() === normalizedEmail && u.password === password);

    // Guaranteed fallback for all demo logins
    if (!matchedUser && (
      normalizedEmail === 'student@lumarail.com' || 
      normalizedEmail === 'student@aurarail.com' || 
      normalizedEmail === 'evaluator@lumarail.com' || 
      normalizedEmail === 'ananya@lumarail.com'
    ) && password === 'password123') {
      matchedUser = {
        id: 'usr_demo_101',
        name: normalizedEmail.includes('evaluator') ? 'Academic Evaluator' : (normalizedEmail.includes('ananya') ? 'Ananya Sharma' : 'Vikramaditya Roy (Student)'),
        email: normalizedEmail,
        phone: '9876543210',
        password: 'password123',
        createdAt: '2026-01-01T00:00:00.000Z'
      };
      users.push(matchedUser);
      localStorage.setItem(this.USERS_KEY, JSON.stringify(users));
    }

    if (!matchedUser) {
      return { success: false, message: this.i18nService.translate('auth.login_failed') };
    }

    this.createSession(matchedUser);
    this.notificationService.success(this.i18nService.translate('auth.login_success'), 'Authenticated');
    return { success: true, message: 'Login successful' };
  }

  loginAsDemoStudent(): void {
    this.login('student@lumarail.com', 'password123');
  }

  private createSession(user: User): void {
    const session: AuthSession = {
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        createdAt: user.createdAt
      },
      token: 'jwt_mock_' + Math.random().toString(36).substring(2),
      loginTime: new Date().toISOString()
    };

    localStorage.setItem(this.SESSION_KEY, JSON.stringify(session));
    this.currentUser.set(session.user);
  }

  logout(): void {
    localStorage.removeItem(this.SESSION_KEY);
    this.currentUser.set(null);
    this.notificationService.info(this.i18nService.translate('auth.logout_success'), 'Signed Out');
  }
}
