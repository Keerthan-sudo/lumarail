import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TrainService } from '../../services/train.service';
import { I18nService } from '../../services/i18n.service';
import { NotificationService } from '../../services/notification.service';
import { Station, Train } from '../../models/train.model';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule, ReactiveFormsModule, TranslatePipe],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
  stations: Station[] = [];
  featuredTrains: Train[] = [];

  // Search parameters
  fromStationCode = 'NDLS';
  toStationCode = 'BSB';
  journeyDate = '';
  travelClass = 'ALL';
  errorMessage = '';

  minDate = '';

  constructor(
    public trainService: TrainService,
    public i18nService: I18nService,
    private notificationService: NotificationService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.stations = this.trainService.getStations();
    this.featuredTrains = this.trainService.getAllTrains().slice(0, 6);

    // Set default date to tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    this.minDate = new Date().toISOString().split('T')[0];
    this.journeyDate = tomorrow.toISOString().split('T')[0];
  }

  swapStations(): void {
    const temp = this.fromStationCode;
    this.fromStationCode = this.toStationCode;
    this.toStationCode = temp;
    this.errorMessage = '';
  }

  onStationChange(): void {
    this.errorMessage = '';
  }

  executeSearch(): void {
    if (!this.fromStationCode || !this.toStationCode) {
      this.errorMessage = 'Please select both origin and destination stations.';
      this.notificationService.warning(this.errorMessage);
      return;
    }

    if (this.fromStationCode === this.toStationCode) {
      this.errorMessage = this.i18nService.translate('search.same_station_error');
      this.notificationService.warning(this.errorMessage, 'Station Conflict');
      return;
    }

    if (!this.journeyDate) {
      this.errorMessage = this.i18nService.translate('search.date_required');
      this.notificationService.warning(this.errorMessage);
      return;
    }

    this.errorMessage = '';
    this.router.navigate(['/search'], {
      queryParams: {
        from: this.fromStationCode,
        to: this.toStationCode,
        date: this.journeyDate,
        class: this.travelClass
      }
    });
  }

  selectPopularRoute(fromCode: string, toCode: string): void {
    this.fromStationCode = fromCode;
    this.toStationCode = toCode;
    this.executeSearch();
  }
}
