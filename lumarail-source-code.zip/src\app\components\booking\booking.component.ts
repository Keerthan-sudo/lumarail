import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { TrainService } from '../../services/train.service';
import { BookingService } from '../../services/booking.service';
import { AuthService } from '../../services/auth.service';
import { I18nService } from '../../services/i18n.service';
import { NotificationService } from '../../services/notification.service';
import { Train, TrainClass } from '../../models/train.model';
import { Booking, FareBreakdown } from '../../models/booking.model';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, TranslatePipe],
  templateUrl: './booking.component.html',
  styleUrl: './booking.component.css'
})
export class BookingComponent implements OnInit {
  train: Train | undefined;
  selectedClass: TrainClass | undefined;
  journeyDate = '';
  
  bookingForm!: FormGroup;
  fareBreakdown: FareBreakdown | null = null;
  
  // Confirmed booking state
  confirmedBooking: Booking | null = null;
  isSubmitting = false;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public trainService: TrainService,
    public bookingService: BookingService,
    public authService: AuthService,
    public i18nService: I18nService,
    private notificationService: NotificationService
  ) {}

  ngOnInit(): void {
    const trainId = this.route.snapshot.paramMap.get('trainId');
    const classCode = this.route.snapshot.paramMap.get('classCode');
    this.journeyDate = this.route.snapshot.queryParamMap.get('date') || new Date().toISOString().split('T')[0];

    if (!trainId || !classCode) {
      this.router.navigate(['/search']);
      return;
    }

    this.train = this.trainService.getTrainById(trainId);
    if (!this.train) {
      this.notificationService.error('Selected train was not found.');
      this.router.navigate(['/search']);
      return;
    }

    this.selectedClass = this.train.classes.find(c => c.code === classCode) || this.train.classes[0];

    this.initForm();
    this.updateFareCalculation();
  }

  private initForm(): void {
    const user = this.authService.currentUser();

    this.bookingForm = this.fb.group({
      contactPhone: [user?.phone || '', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
      contactEmail: [user?.email || '', [Validators.required, Validators.email]],
      passengers: this.fb.array([this.createPassengerGroup(user?.name || '')])
    });

    // Recalculate fare when passengers change
    this.passengersArray.valueChanges.subscribe(() => {
      this.updateFareCalculation();
    });
  }

  get passengersArray(): FormArray {
    return this.bookingForm.get('passengers') as FormArray;
  }

  private createPassengerGroup(defaultName = ''): FormGroup {
    return this.fb.group({
      name: [defaultName, [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
      age: [25, [Validators.required, Validators.min(1), Validators.max(120)]],
      gender: ['Male', [Validators.required]],
      berthPreference: ['No Preference']
    });
  }

  addPassenger(): void {
    if (this.passengersArray.length >= 6) {
      this.notificationService.warning(this.i18nService.translate('booking.max_passengers_notice'));
      return;
    }
    this.passengersArray.push(this.createPassengerGroup());
    this.updateFareCalculation();
  }

  removePassenger(index: number): void {
    if (this.passengersArray.length <= 1) {
      this.notificationService.info('At least one passenger is required for the ticket.');
      return;
    }
    this.passengersArray.removeAt(index);
    this.updateFareCalculation();
  }

  updateFareCalculation(): void {
    if (!this.selectedClass) return;
    const count = this.passengersArray ? this.passengersArray.length : 1;
    this.fareBreakdown = this.bookingService.calculateFare(this.selectedClass.baseFare, count);
  }

  submitBooking(): void {
    if (this.bookingForm.invalid) {
      this.bookingForm.markAllAsTouched();
      this.notificationService.warning('Please fill in all passenger and contact information correctly.');
      return;
    }

    const user = this.authService.currentUser();
    if (!user) {
      this.notificationService.warning('Please sign in to confirm your booking.');
      this.router.navigate(['/login'], { queryParams: { returnUrl: this.router.url } });
      return;
    }

    if (!this.train || !this.selectedClass) return;

    this.isSubmitting = true;

    const formValues = this.bookingForm.value;
    const rawPassengers = formValues.passengers;

    setTimeout(() => {
      this.confirmedBooking = this.bookingService.createBooking(
        user,
        this.train!,
        this.selectedClass!,
        this.journeyDate,
        rawPassengers,
        formValues.contactPhone,
        formValues.contactEmail
      );
      this.isSubmitting = false;
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 600);
  }

  printTicket(): void {
    window.print();
  }

  goToMyBookings(): void {
    this.router.navigate(['/my-bookings']);
  }
}
