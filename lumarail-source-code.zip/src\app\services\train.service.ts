import { Injectable } from '@angular/core';
import { Station, Train, TrainClass } from '../models/train.model';

@Injectable({
  providedIn: 'root'
})
export class TrainService {

  readonly stations: Station[] = [
  {
    "code": "NDLS",
    "name": "New Delhi Railway Station",
    "city": "New Delhi",
    "state": "Delhi"
  },
  {
    "code": "CSMT",
    "name": "Chhatrapati Shivaji Maharaj Terminus",
    "city": "Mumbai",
    "state": "Maharashtra"
  },
  {
    "code": "SBC",
    "name": "KSR Bengaluru City",
    "city": "Bengaluru",
    "state": "Karnataka"
  },
  {
    "code": "HYB",
    "name": "Hyderabad Deccan Station",
    "city": "Hyderabad",
    "state": "Telangana"
  },
  {
    "code": "MAS",
    "name": "MGR Chennai Central",
    "city": "Chennai",
    "state": "Tamil Nadu"
  },
  {
    "code": "HWH",
    "name": "Howrah Junction",
    "city": "Kolkata",
    "state": "West Bengal"
  },
  {
    "code": "MAO",
    "name": "Madgaon Junction Goa",
    "city": "Goa",
    "state": "Goa"
  },
  {
    "code": "BSB",
    "name": "Varanasi Junction",
    "city": "Varanasi",
    "state": "Uttar Pradesh"
  },
  {
    "code": "JP",
    "name": "Jaipur Junction",
    "city": "Jaipur",
    "state": "Rajasthan"
  },
  {
    "code": "ADI",
    "name": "Ahmedabad Junction",
    "city": "Ahmedabad",
    "state": "Gujarat"
  },
  {
    "code": "CDG",
    "name": "Chandigarh Junction",
    "city": "Chandigarh",
    "state": "Punjab"
  },
  {
    "code": "PNBE",
    "name": "Patna Junction",
    "city": "Patna",
    "state": "Bihar"
  },
  {
    "code": "LKO",
    "name": "Lucknow Charbagh",
    "city": "Lucknow",
    "state": "Uttar Pradesh"
  },
  {
    "code": "BPL",
    "name": "Bhopal Rani Kamlapati",
    "city": "Bhopal",
    "state": "Madhya Pradesh"
  },
  {
    "code": "PUNE",
    "name": "Pune Junction",
    "city": "Pune",
    "state": "Maharashtra"
  },
  {
    "code": "TVC",
    "name": "Thiruvananthapuram Central",
    "city": "Thiruvananthapuram",
    "state": "Kerala"
  },
  {
    "code": "GHY",
    "name": "Guwahati Junction",
    "city": "Guwahati",
    "state": "Assam"
  },
  {
    "code": "AGC",
    "name": "Agra Cantt",
    "city": "Agra",
    "state": "Uttar Pradesh"
  },
  {
    "code": "SVDK",
    "name": "SMVD Katra",
    "city": "Katra",
    "state": "Jammu & Kashmir"
  },
  {
    "code": "BBS",
    "name": "Bhubaneswar Junction",
    "city": "Bhubaneswar",
    "state": "Odisha"
  },
  {
    "code": "CNB",
    "name": "Kanpur Central",
    "city": "Kanpur",
    "state": "Uttar Pradesh"
  },
  {
    "code": "ERS",
    "name": "Ernakulam Junction",
    "city": "Kochi",
    "state": "Kerala"
  },
  {
    "code": "ASR",
    "name": "Amritsar Junction",
    "city": "Amritsar",
    "state": "Punjab"
  },
  {
    "code": "SC",
    "name": "Secunderabad Junction",
    "city": "Secunderabad",
    "state": "Telangana"
  }
];

  private readonly primaryTrains: Train[] = [
    {
      id: 'trn_22436',
      trainNumber: '22436',
      trainName: 'Vande Bharat Express',
      trainType: 'Vande Bharat',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"BSB","name":"Varanasi Junction","city":"Varanasi","state":"Uttar Pradesh"},
      departureTime: '06:00 AM',
      arrivalTime: '02:00 PM',
      duration: '8h 00m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 759,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 4,
      highlight: 'Aero-Dynamic Bullet Profile, Bio-Toilets & Onboard Infotainment',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1750,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["Gourmet Breakfast","WiFi","Ergonomic Recline"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 3300,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["180° Rotating Seats","Luxury 3-Course Dining","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12560',
      trainNumber: '12560',
      trainName: 'Shiv Ganga Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"BSB","name":"Varanasi Junction","city":"Varanasi","state":"Uttar Pradesh"},
      departureTime: '08:05 PM',
      arrivalTime: '07:10 AM',
      duration: '11h 05m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 759,
      rating: 4.7,
      foodIncluded: false,
      haltsCount: 3,
      highlight: 'Flagship Non-Stop Overnight Corridor to Varanasi',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 440,
          availableSeats: 65,
          status: 'AVAILABLE',
          statusNumber: 65,
          coachCodePrefix: 'S',
          perks: ["Comfort Berth","Night Quiet Time"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1180,
          availableSeats: 28,
          status: 'AVAILABLE',
          statusNumber: 28,
          coachCodePrefix: 'B',
          perks: ["Fresh Bedding Kit","Mobile Charging"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1690,
          availableSeats: 12,
          status: 'AVAILABLE',
          statusNumber: 12,
          coachCodePrefix: 'A',
          perks: ["Curtained Privacy","Reading Lamp"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 2840,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["Coupe Privacy","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_22418',
      trainNumber: '22418',
      trainName: 'Mahamana Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"BSB","name":"Varanasi Junction","city":"Varanasi","state":"Uttar Pradesh"},
      departureTime: '06:35 PM',
      arrivalTime: '08:25 AM',
      duration: '13h 50m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 759,
      rating: 4.6,
      foodIncluded: false,
      haltsCount: 8,
      highlight: 'Modern Ergonomic Coaches with LED Mood Lighting & Bio-Toilets',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 420,
          availableSeats: 52,
          status: 'AVAILABLE',
          statusNumber: 52,
          coachCodePrefix: 'S',
          perks: ["Night Berth","Pantry Service"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1140,
          availableSeats: 18,
          status: 'RAC',
          statusNumber: 18,
          coachCodePrefix: 'B',
          perks: ["Clean Linens","AC Comfort"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1620,
          availableSeats: 9,
          status: 'AVAILABLE',
          statusNumber: 9,
          coachCodePrefix: 'A',
          perks: ["Wide Windows","Quiet Coach"]
        }
      ]
    },
    {
      id: 'trn_22435',
      trainNumber: '22435',
      trainName: 'Vande Bharat Express',
      trainType: 'Vande Bharat',
      fromStation: {"code":"BSB","name":"Varanasi Junction","city":"Varanasi","state":"Uttar Pradesh"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '03:00 PM',
      arrivalTime: '11:00 PM',
      duration: '8h 00m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 759,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 4,
      highlight: 'Return Prime Corridor from Varanasi to Capital',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1750,
          availableSeats: 42,
          status: 'AVAILABLE',
          statusNumber: 42,
          coachCodePrefix: 'C',
          perks: ["Gourmet High Tea & Dinner","WiFi","Panoramic Windows"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 3300,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Curated Dinner","Priority Luggage"]
        }
      ]
    },
    {
      id: 'trn_12559',
      trainNumber: '12559',
      trainName: 'Shiv Ganga Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"BSB","name":"Varanasi Junction","city":"Varanasi","state":"Uttar Pradesh"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '10:15 PM',
      arrivalTime: '08:25 AM',
      duration: '10h 10m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 759,
      rating: 4.7,
      foodIncluded: false,
      haltsCount: 3,
      highlight: 'Overnight Superfast Express to New Delhi',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 440,
          availableSeats: 58,
          status: 'AVAILABLE',
          statusNumber: 58,
          coachCodePrefix: 'S',
          perks: ["Cushioned Berths","Night Lamp"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1180,
          availableSeats: 31,
          status: 'AVAILABLE',
          statusNumber: 31,
          coachCodePrefix: 'B',
          perks: ["Sanitized Linen Kit","Charging Sockets"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1690,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'A',
          perks: ["Curtained Privacy","Quiet Ambient Lighting"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 2840,
          availableSeats: 5,
          status: 'AVAILABLE',
          statusNumber: 5,
          coachCodePrefix: 'H',
          perks: ["Private Coupe","Welcome Kit"]
        }
      ]
    },
    {
      id: 'trn_12952',
      trainNumber: '12952',
      trainName: 'Mumbai Tejas Rajdhani Express',
      trainType: 'Rajdhani Superfast',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      departureTime: '04:55 PM',
      arrivalTime: '08:35 AM',
      duration: '15h 40m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1384,
      rating: 4.85,
      foodIncluded: true,
      haltsCount: 6,
      highlight: 'Flagship High-Speed Overnight Corridor with Automatic Smart Doors',
      classes: [
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 2340,
          availableSeats: 32,
          status: 'AVAILABLE',
          statusNumber: 32,
          coachCodePrefix: 'B',
          perks: ["Fresh Bedroll Kit","Complimentary Dinner","Charging Hub"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 3620,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'A',
          perks: ["Curtained Privacy","Hot Plated Meals","Reading Lamps"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 5480,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["Lockable 2/4-Berth Coupe","Personal Attendant","Continental High Tea"]
        }
      ]
    },
    {
      id: 'trn_12954',
      trainNumber: '12954',
      trainName: 'August Kranti Tejas Rajdhani',
      trainType: 'Rajdhani Superfast',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      departureTime: '05:15 PM',
      arrivalTime: '10:05 AM',
      duration: '16h 50m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1377,
      rating: 4.8,
      foodIncluded: true,
      haltsCount: 10,
      highlight: 'Legendary Capital to Financial Hub Express with Gourmet Catering',
      classes: [
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 2280,
          availableSeats: 40,
          status: 'AVAILABLE',
          statusNumber: 40,
          coachCodePrefix: 'B',
          perks: ["Dinner & Breakfast Included","Wifi Infotainment"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 3510,
          availableSeats: 18,
          status: 'AVAILABLE',
          statusNumber: 18,
          coachCodePrefix: 'A',
          perks: ["Spacious 2x2 Berths","Quiet Cabins"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 5320,
          availableSeats: 4,
          status: 'AVAILABLE',
          statusNumber: 4,
          coachCodePrefix: 'H',
          perks: ["Private Cabin","Shower Facility","Personal Butler"]
        }
      ]
    },
    {
      id: 'trn_12248',
      trainNumber: '12248',
      trainName: 'Mumbai Yuva Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      departureTime: '11:25 AM',
      arrivalTime: '06:15 AM',
      duration: '18h 50m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1366,
      rating: 4.5,
      foodIncluded: false,
      haltsCount: 8,
      highlight: 'Affordable High-Speed Transit with Modern LHB AC Coaches',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 620,
          availableSeats: 72,
          status: 'AVAILABLE',
          statusNumber: 72,
          coachCodePrefix: 'S',
          perks: ["Comfort Berth","Affordable Overnight"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1640,
          availableSeats: 44,
          status: 'AVAILABLE',
          statusNumber: 44,
          coachCodePrefix: 'B',
          perks: ["Fresh Linens","AC Comfort"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 2380,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'A',
          perks: ["Curtained Berths","Mobile Ports"]
        }
      ]
    },
    {
      id: 'trn_12926',
      trainNumber: '12926',
      trainName: 'Paschim Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      departureTime: '04:25 PM',
      arrivalTime: '02:45 PM',
      duration: '22h 20m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1384,
      rating: 4.6,
      foodIncluded: false,
      haltsCount: 22,
      highlight: 'Heritage Western Railway Trunk Corridor Connecting Capital & Mumbai',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 590,
          availableSeats: 84,
          status: 'AVAILABLE',
          statusNumber: 84,
          coachCodePrefix: 'S',
          perks: ["Reserved Berth","Pantry Service"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1580,
          availableSeats: 36,
          status: 'AVAILABLE',
          statusNumber: 36,
          coachCodePrefix: 'B',
          perks: ["AC Comfort","Sanitized Bedrolls"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 2280,
          availableSeats: 18,
          status: 'AVAILABLE',
          statusNumber: 18,
          coachCodePrefix: 'A',
          perks: ["Spacious Berths","Reading Lights"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 3950,
          availableSeats: 8,
          status: 'AVAILABLE',
          statusNumber: 8,
          coachCodePrefix: 'H',
          perks: ["First AC Luxury Coupe","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_12951',
      trainNumber: '12951',
      trainName: 'Mumbai Tejas Rajdhani Express',
      trainType: 'Rajdhani Superfast',
      fromStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '05:00 PM',
      arrivalTime: '08:32 AM',
      duration: '15h 32m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1384,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 6,
      highlight: 'Premier Overnight High-Speed Journey from Mumbai to Delhi',
      classes: [
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 2340,
          availableSeats: 38,
          status: 'AVAILABLE',
          statusNumber: 38,
          coachCodePrefix: 'B',
          perks: ["Multi-Course Dinner","Fresh Bedroll","WiFi"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 3620,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'A',
          perks: ["Curtained Luxury","Warm Meals","Express Transit"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 5480,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["Private Coupe","Butler Service","Gourmet Menu"]
        }
      ]
    },
    {
      id: 'trn_12953',
      trainNumber: '12953',
      trainName: 'August Kranti Tejas Rajdhani',
      trainType: 'Rajdhani Superfast',
      fromStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '05:40 PM',
      arrivalTime: '10:55 AM',
      duration: '17h 15m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1377,
      rating: 4.8,
      foodIncluded: true,
      haltsCount: 10,
      highlight: 'Premium Tejas Coaches with Bio-Vacuum Toilets & Chef Catering',
      classes: [
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 2280,
          availableSeats: 35,
          status: 'AVAILABLE',
          statusNumber: 35,
          coachCodePrefix: 'B',
          perks: ["Hot Meals Included","Clean Bedding Kit"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 3510,
          availableSeats: 15,
          status: 'AVAILABLE',
          statusNumber: 15,
          coachCodePrefix: 'A',
          perks: ["Quiet Coupe Area","Reading Lamps"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 5320,
          availableSeats: 5,
          status: 'AVAILABLE',
          statusNumber: 5,
          coachCodePrefix: 'H',
          perks: ["Executive Coupe","Continental Breakfast"]
        }
      ]
    },
    {
      id: 'trn_12137',
      trainNumber: '12137',
      trainName: 'Punjab Mail Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '07:35 PM',
      arrivalTime: '09:30 PM',
      duration: '25h 55m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1541,
      rating: 4.5,
      foodIncluded: false,
      haltsCount: 30,
      highlight: 'Historic 112-Year-Old Legendary Mail Connecting Financial Capital to Delhi',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 620,
          availableSeats: 92,
          status: 'AVAILABLE',
          statusNumber: 92,
          coachCodePrefix: 'S',
          perks: ["Classic Berth","Pantry Meals"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1650,
          availableSeats: 40,
          status: 'AVAILABLE',
          statusNumber: 40,
          coachCodePrefix: 'B',
          perks: ["AC 3-Tier Comfort","Charging Points"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 2410,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'A',
          perks: ["Wide Windows","Quiet Coach"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 4100,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["Heritage First AC Coupe","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_20608',
      trainNumber: '20608',
      trainName: 'Mysuru - Chennai Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      toStation: {"code":"MAS","name":"MGR Chennai Central","city":"Chennai","state":"Tamil Nadu"},
      departureTime: '02:50 PM',
      arrivalTime: '07:20 PM',
      duration: '4h 30m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 359,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 2,
      highlight: 'High-Speed Aerodynamic Express with 160 kmph Capability & Infotainment',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 995,
          availableSeats: 56,
          status: 'AVAILABLE',
          statusNumber: 56,
          coachCodePrefix: 'C',
          perks: ["South Indian High Tea","Starlink WiFi","Ergonomic Recline"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 1885,
          availableSeats: 18,
          status: 'AVAILABLE',
          statusNumber: 18,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Curated Evening Snacks","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12028',
      trainNumber: '12028',
      trainName: 'KSR Bengaluru - Chennai Shatabdi',
      trainType: 'Shatabdi Express',
      fromStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      toStation: {"code":"MAS","name":"MGR Chennai Central","city":"Chennai","state":"Tamil Nadu"},
      departureTime: '06:00 AM',
      arrivalTime: '11:00 AM',
      duration: '5h 00m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 359,
      rating: 4.8,
      foodIncluded: true,
      haltsCount: 3,
      highlight: 'Flagship Morning Executive Commuter with Full Breakfast Service',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 865,
          availableSeats: 62,
          status: 'AVAILABLE',
          statusNumber: 62,
          coachCodePrefix: 'C',
          perks: ["Hot Idli Vada / Continental Breakfast","Mineral Water"]
        },
        {
          code: '1A',
          name: 'Executive Class (EC)',
          baseFare: 1650,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'E',
          perks: ["Spacious Recliner","Multi-Course Dining","Newspapers"]
        }
      ]
    },
    {
      id: 'trn_12640',
      trainNumber: '12640',
      trainName: 'Brindavan Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      toStation: {"code":"MAS","name":"MGR Chennai Central","city":"Chennai","state":"Tamil Nadu"},
      departureTime: '03:10 PM',
      arrivalTime: '09:05 PM',
      duration: '5h 55m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 359,
      rating: 4.65,
      foodIncluded: false,
      haltsCount: 9,
      highlight: 'Classic Intercity Express between Silicon Valley and Southern Metropolis',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 520,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["AC Comfort","Large Windows"]
        },
        {
          code: 'SL',
          name: 'Second Seating (2S)',
          baseFare: 185,
          availableSeats: 110,
          status: 'AVAILABLE',
          statusNumber: 110,
          coachCodePrefix: 'D',
          perks: ["Guaranteed Reserved Seat","Affordable Commute"]
        }
      ]
    },
    {
      id: 'trn_12608',
      trainNumber: '12608',
      trainName: 'Lalbagh Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      toStation: {"code":"MAS","name":"MGR Chennai Central","city":"Chennai","state":"Tamil Nadu"},
      departureTime: '06:20 AM',
      arrivalTime: '12:15 PM',
      duration: '5h 55m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 359,
      rating: 4.6,
      foodIncluded: false,
      haltsCount: 10,
      highlight: 'Reliable Morning Intercity Corridor with Scenic Views of Deccan Plateau',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 515,
          availableSeats: 38,
          status: 'AVAILABLE',
          statusNumber: 38,
          coachCodePrefix: 'C',
          perks: ["Chilled AC Comfort","Mobile Charging"]
        },
        {
          code: 'SL',
          name: 'Second Seating (2S)',
          baseFare: 180,
          availableSeats: 95,
          status: 'AVAILABLE',
          statusNumber: 95,
          coachCodePrefix: 'D',
          perks: ["Reserved Seating","Quick Boarding"]
        }
      ]
    },
    {
      id: 'trn_20607',
      trainNumber: '20607',
      trainName: 'Chennai - Mysuru Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"MAS","name":"MGR Chennai Central","city":"Chennai","state":"Tamil Nadu"},
      toStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      departureTime: '05:50 AM',
      arrivalTime: '10:20 AM',
      duration: '4h 30m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 359,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 2,
      highlight: 'Flagship Morning High-Speed Corridor to Bengaluru',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 995,
          availableSeats: 52,
          status: 'AVAILABLE',
          statusNumber: 52,
          coachCodePrefix: 'C',
          perks: ["Gourmet Breakfast","Starlink WiFi","Ergonomic Recline"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 1885,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Chef Breakfast","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12027',
      trainNumber: '12027',
      trainName: 'Chennai - Bengaluru Shatabdi',
      trainType: 'Shatabdi Express',
      fromStation: {"code":"MAS","name":"MGR Chennai Central","city":"Chennai","state":"Tamil Nadu"},
      toStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      departureTime: '05:30 PM',
      arrivalTime: '10:25 PM',
      duration: '4h 55m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 359,
      rating: 4.8,
      foodIncluded: true,
      haltsCount: 3,
      highlight: 'Evening Executive Commuter with Complimentary Hot Dinner',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 865,
          availableSeats: 58,
          status: 'AVAILABLE',
          statusNumber: 58,
          coachCodePrefix: 'C',
          perks: ["Plated Dinner Service","Mineral Water"]
        },
        {
          code: '1A',
          name: 'Executive Class (EC)',
          baseFare: 1650,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'E',
          perks: ["Comfortable Recliner","Special Dinner Platter"]
        }
      ]
    },
    {
      id: 'trn_12639',
      trainNumber: '12639',
      trainName: 'Brindavan Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"MAS","name":"MGR Chennai Central","city":"Chennai","state":"Tamil Nadu"},
      toStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      departureTime: '07:40 AM',
      arrivalTime: '01:40 PM',
      duration: '6h 00m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 359,
      rating: 4.65,
      foodIncluded: false,
      haltsCount: 9,
      highlight: 'Daytime Non-Stop Express connecting Chennai Central to Bengaluru',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 520,
          availableSeats: 50,
          status: 'AVAILABLE',
          statusNumber: 50,
          coachCodePrefix: 'C',
          perks: ["AC Seating","Pantry Snacks"]
        },
        {
          code: 'SL',
          name: 'Second Seating (2S)',
          baseFare: 185,
          availableSeats: 120,
          status: 'AVAILABLE',
          statusNumber: 120,
          coachCodePrefix: 'D',
          perks: ["Reserved Seat","Economical Fare"]
        }
      ]
    },
    {
      id: 'trn_22229',
      trainNumber: '22229',
      trainName: 'Mumbai - Madgaon Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      toStation: {"code":"MAO","name":"Madgaon Junction Goa","city":"Goa","state":"Goa"},
      departureTime: '05:25 AM',
      arrivalTime: '01:10 PM',
      duration: '7h 45m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 586,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 7,
      highlight: 'Panoramic Konkan Coastal Vista Corridor with Floor-to-Ceiling Windows',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1435,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["Breakfast & Lunch Included","WiFi","Scenic Windows"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2790,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["180° Rotating Seats","Konkan Coastal Platter","Priority Check-in"]
        }
      ]
    },
    {
      id: 'trn_10103',
      trainNumber: '10103',
      trainName: 'Mandovi Scenic Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      toStation: {"code":"MAO","name":"Madgaon Junction Goa","city":"Goa","state":"Goa"},
      departureTime: '07:10 AM',
      arrivalTime: '07:00 PM',
      duration: '11h 50m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 586,
      rating: 4.8,
      foodIncluded: false,
      haltsCount: 15,
      highlight: 'World Famous Daytime Konkan Railway Experience across 2,000+ Bridges',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 380,
          availableSeats: 75,
          status: 'AVAILABLE',
          statusNumber: 75,
          coachCodePrefix: 'S',
          perks: ["Open Window Sea Breeze","Konkan Scenery"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1020,
          availableSeats: 36,
          status: 'AVAILABLE',
          statusNumber: 36,
          coachCodePrefix: 'B',
          perks: ["AC Comfort","Pantry Delicacies"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1470,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'A',
          perks: ["Spacious Berths","Quiet Coach"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 2480,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["Luxury Coupe","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_20111',
      trainNumber: '20111',
      trainName: 'Konkan Kanya Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      toStation: {"code":"MAO","name":"Madgaon Junction Goa","city":"Goa","state":"Goa"},
      departureTime: '11:05 PM',
      arrivalTime: '10:45 AM',
      duration: '11h 40m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 586,
      rating: 4.75,
      foodIncluded: false,
      haltsCount: 16,
      highlight: 'Beloved Overnight Konkan Route to Goa Beaches',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 380,
          availableSeats: 80,
          status: 'AVAILABLE',
          statusNumber: 80,
          coachCodePrefix: 'S',
          perks: ["Overnight Sleeper","Night Lamp"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1020,
          availableSeats: 34,
          status: 'AVAILABLE',
          statusNumber: 34,
          coachCodePrefix: 'B',
          perks: ["Clean Bedrolls","Air Conditioned"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1470,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'A',
          perks: ["Curtained Privacy","Quiet Ambient Lighting"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 2480,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["Private Cabin","Welcome Refreshment"]
        }
      ]
    },
    {
      id: 'trn_22230',
      trainNumber: '22230',
      trainName: 'Madgaon - Mumbai Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"MAO","name":"Madgaon Junction Goa","city":"Goa","state":"Goa"},
      toStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      departureTime: '02:40 PM',
      arrivalTime: '10:25 PM',
      duration: '7h 45m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 586,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 7,
      highlight: 'Return Sunset Corridor through the Majestic Western Ghats & Tunnels',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1435,
          availableSeats: 45,
          status: 'AVAILABLE',
          statusNumber: 45,
          coachCodePrefix: 'C',
          perks: ["Gourmet Evening High Tea & Dinner","WiFi","Scenic Windows"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2790,
          availableSeats: 15,
          status: 'AVAILABLE',
          statusNumber: 15,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Luxury 3-Course Dinner","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_10104',
      trainNumber: '10104',
      trainName: 'Mandovi Scenic Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"MAO","name":"Madgaon Junction Goa","city":"Goa","state":"Goa"},
      toStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      departureTime: '09:15 AM',
      arrivalTime: '09:45 PM',
      duration: '12h 30m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 586,
      rating: 4.8,
      foodIncluded: false,
      haltsCount: 15,
      highlight: 'Daytime Coastal Journey with Fresh Sea Breeze & Waterfall Vistas',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 380,
          availableSeats: 68,
          status: 'AVAILABLE',
          statusNumber: 68,
          coachCodePrefix: 'S',
          perks: ["Window Berth","Pantry Seafood & Snacks"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1020,
          availableSeats: 30,
          status: 'AVAILABLE',
          statusNumber: 30,
          coachCodePrefix: 'B',
          perks: ["Chilled AC Cabin","Charging Outlets"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1470,
          availableSeats: 12,
          status: 'AVAILABLE',
          statusNumber: 12,
          coachCodePrefix: 'A',
          perks: ["Spacious 2x2 Berth","Quiet Coach"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 2480,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["Private AC Coupe","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_12302',
      trainNumber: '12302',
      trainName: 'Howrah Tejas Rajdhani Express',
      trainType: 'Rajdhani Superfast',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"HWH","name":"Howrah Junction","city":"Kolkata","state":"West Bengal"},
      departureTime: '04:55 PM',
      arrivalTime: '09:55 AM',
      duration: '17h 00m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1451,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 7,
      highlight: 'India’s Historic First Rajdhani Express with Automatic Smart Tejas Coaches',
      classes: [
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 2420,
          availableSeats: 36,
          status: 'AVAILABLE',
          statusNumber: 36,
          coachCodePrefix: 'B',
          perks: ["Multi-Course Bengali & North Indian Dinner","Linens"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 3740,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'A',
          perks: ["Curtained Privacy","Gourmet High Tea & Dinner"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 5680,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["Private Lockable Coupe","Dedicated Butler"]
        }
      ]
    },
    {
      id: 'trn_12304',
      trainNumber: '12304',
      trainName: 'Poorva Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"HWH","name":"Howrah Junction","city":"Kolkata","state":"West Bengal"},
      departureTime: '05:40 PM',
      arrivalTime: '05:00 PM',
      duration: '23h 20m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1451,
      rating: 4.65,
      foodIncluded: false,
      haltsCount: 20,
      highlight: 'Historic Eastern Corridor Connecting Capital to the City of Joy',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 630,
          availableSeats: 78,
          status: 'AVAILABLE',
          statusNumber: 78,
          coachCodePrefix: 'S',
          perks: ["Reserved Berth","Pantry Meal Service"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1680,
          availableSeats: 34,
          status: 'AVAILABLE',
          statusNumber: 34,
          coachCodePrefix: 'B',
          perks: ["AC 3-Tier Comfort","Fresh Bedrolls"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 2440,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'A',
          perks: ["Spacious Berths","Reading Lights"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 4180,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["First AC Coupe","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_12312',
      trainNumber: '12312',
      trainName: 'Netaji Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"HWH","name":"Howrah Junction","city":"Kolkata","state":"West Bengal"},
      departureTime: '06:15 AM',
      arrivalTime: '08:05 AM',
      duration: '25h 50m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1530,
      rating: 4.6,
      foodIncluded: false,
      haltsCount: 35,
      highlight: 'Grand Trunk National Heritage Train with 150+ Years of History',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 640,
          availableSeats: 85,
          status: 'AVAILABLE',
          statusNumber: 85,
          coachCodePrefix: 'S',
          perks: ["Heritage Journey","Clean Berths"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1710,
          availableSeats: 38,
          status: 'AVAILABLE',
          statusNumber: 38,
          coachCodePrefix: 'B',
          perks: ["Air Conditioned","Bedding Kit"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 2480,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'A',
          perks: ["Curtained Privacy","Quiet Coach"]
        }
      ]
    },
    {
      id: 'trn_12301',
      trainNumber: '12301',
      trainName: 'Howrah Tejas Rajdhani Express',
      trainType: 'Rajdhani Superfast',
      fromStation: {"code":"HWH","name":"Howrah Junction","city":"Kolkata","state":"West Bengal"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '04:50 PM',
      arrivalTime: '10:05 AM',
      duration: '17h 15m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1451,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 7,
      highlight: 'Return High-Speed Overnight Rajdhani Corridor to New Delhi',
      classes: [
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 2420,
          availableSeats: 32,
          status: 'AVAILABLE',
          statusNumber: 32,
          coachCodePrefix: 'B',
          perks: ["Complimentary Hot Dinner & Breakfast","WiFi"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 3740,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'A',
          perks: ["Curtained Berths","Chef-Prepared Meals"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 5680,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["Private Coupe","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_12303',
      trainNumber: '12303',
      trainName: 'Poorva Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"HWH","name":"Howrah Junction","city":"Kolkata","state":"West Bengal"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '08:00 AM',
      arrivalTime: '06:00 AM',
      duration: '22h 00m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1451,
      rating: 4.65,
      foodIncluded: false,
      haltsCount: 20,
      highlight: 'Classic Grand Trunk Superfast via Patna and Kanpur to New Delhi',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 630,
          availableSeats: 72,
          status: 'AVAILABLE',
          statusNumber: 72,
          coachCodePrefix: 'S',
          perks: ["Reserved Berth","Pantry Service"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1680,
          availableSeats: 36,
          status: 'AVAILABLE',
          statusNumber: 36,
          coachCodePrefix: 'B',
          perks: ["AC Comfort","Linens Provided"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 2440,
          availableSeats: 15,
          status: 'AVAILABLE',
          statusNumber: 15,
          coachCodePrefix: 'A',
          perks: ["Quiet Berth","Reading Lamp"]
        }
      ]
    },
    {
      id: 'trn_22447',
      trainNumber: '22447',
      trainName: 'New Delhi - Amb Andaura Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"CDG","name":"Chandigarh Junction","city":"Chandigarh","state":"Punjab"},
      departureTime: '05:50 AM',
      arrivalTime: '08:40 AM',
      duration: '2h 50m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 244,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 2,
      highlight: 'Fastest Transit to the City Beautiful at 130 km/h with Executive Breakfast',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 850,
          availableSeats: 54,
          status: 'AVAILABLE',
          statusNumber: 54,
          coachCodePrefix: 'C',
          perks: ["Warm Breakfast","WiFi","Modern Recliner"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 1680,
          availableSeats: 18,
          status: 'AVAILABLE',
          statusNumber: 18,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Gourmet Morning Platter","Priority Check-in"]
        }
      ]
    },
    {
      id: 'trn_12011',
      trainNumber: '12011',
      trainName: 'Kalka Shatabdi Express',
      trainType: 'Shatabdi Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"CDG","name":"Chandigarh Junction","city":"Chandigarh","state":"Punjab"},
      departureTime: '07:40 AM',
      arrivalTime: '11:05 AM',
      duration: '3h 25m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 244,
      rating: 4.8,
      foodIncluded: true,
      haltsCount: 3,
      highlight: 'Morning Executive Commuter Train with Complimentary Breakfast & Juice',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 720,
          availableSeats: 52,
          status: 'AVAILABLE',
          statusNumber: 52,
          coachCodePrefix: 'C',
          perks: ["Warm Breakfast","Bottled Mineral Water"]
        },
        {
          code: '1A',
          name: 'Executive Class (EC)',
          baseFare: 1450,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'E',
          perks: ["Priority Boarding","Juices & Fruits"]
        }
      ]
    },
    {
      id: 'trn_12005',
      trainNumber: '12005',
      trainName: 'New Delhi - Kalka Evening Shatabdi',
      trainType: 'Shatabdi Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"CDG","name":"Chandigarh Junction","city":"Chandigarh","state":"Punjab"},
      departureTime: '05:15 PM',
      arrivalTime: '08:40 PM',
      duration: '3h 25m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 244,
      rating: 4.8,
      foodIncluded: true,
      haltsCount: 3,
      highlight: 'Evening High-Speed Commuter with Fresh Snacks & Plated Dinner',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 720,
          availableSeats: 46,
          status: 'AVAILABLE',
          statusNumber: 46,
          coachCodePrefix: 'C',
          perks: ["Hot Evening Refreshments & Dinner","Newspaper"]
        },
        {
          code: '1A',
          name: 'Executive Class (EC)',
          baseFare: 1450,
          availableSeats: 12,
          status: 'AVAILABLE',
          statusNumber: 12,
          coachCodePrefix: 'E',
          perks: ["Spacious 2x2 Seating","Executive Meal Platter"]
        }
      ]
    },
    {
      id: 'trn_22448',
      trainNumber: '22448',
      trainName: 'Chandigarh - New Delhi Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"CDG","name":"Chandigarh Junction","city":"Chandigarh","state":"Punjab"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '06:15 PM',
      arrivalTime: '09:05 PM',
      duration: '2h 50m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 244,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 2,
      highlight: 'High-Speed Evening Corridor from Chandigarh to Capital',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 850,
          availableSeats: 50,
          status: 'AVAILABLE',
          statusNumber: 50,
          coachCodePrefix: 'C',
          perks: ["Hot Evening Dinner Platter","WiFi","Smooth Ride"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 1680,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["Rotating Seats","Special Plated Dinner","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12012',
      trainNumber: '12012',
      trainName: 'Chandigarh - New Delhi Shatabdi',
      trainType: 'Shatabdi Express',
      fromStation: {"code":"CDG","name":"Chandigarh Junction","city":"Chandigarh","state":"Punjab"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '06:50 PM',
      arrivalTime: '10:10 PM',
      duration: '3h 20m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 244,
      rating: 4.8,
      foodIncluded: true,
      haltsCount: 3,
      highlight: 'Reliable Evening Commuter with Dinner Service',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 720,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["Hot Plated Dinner","Mineral Water"]
        },
        {
          code: '1A',
          name: 'Executive Class (EC)',
          baseFare: 1450,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'E',
          perks: ["Executive Recliner","Multi-Course Dinner"]
        }
      ]
    },
    {
      id: 'trn_20703',
      trainNumber: '20703',
      trainName: 'Kacheguda - Bengaluru Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"HYB","name":"Hyderabad Deccan Station","city":"Hyderabad","state":"Telangana"},
      toStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      departureTime: '05:30 AM',
      arrivalTime: '02:00 PM',
      duration: '8h 30m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 610,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 4,
      highlight: 'Premier High-Speed Tech Corridor connecting Hyderabad & Bengaluru',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1540,
          availableSeats: 46,
          status: 'AVAILABLE',
          statusNumber: 46,
          coachCodePrefix: 'C',
          perks: ["Breakfast & Lunch Included","Starlink WiFi"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2950,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Deccan Gourmet Dining","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12785',
      trainNumber: '12785',
      trainName: 'Kacheguda - Bengaluru Superfast',
      trainType: 'Superfast Express',
      fromStation: {"code":"HYB","name":"Hyderabad Deccan Station","city":"Hyderabad","state":"Telangana"},
      toStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      departureTime: '07:05 PM',
      arrivalTime: '06:25 AM',
      duration: '11h 20m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 610,
      rating: 4.65,
      foodIncluded: false,
      haltsCount: 11,
      highlight: 'Trusted Overnight Sleeper Express for Tech Professionals & Families',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 395,
          availableSeats: 78,
          status: 'AVAILABLE',
          statusNumber: 78,
          coachCodePrefix: 'S',
          perks: ["Reserved Berth","Night Quiet Time"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1045,
          availableSeats: 34,
          status: 'AVAILABLE',
          statusNumber: 34,
          coachCodePrefix: 'B',
          perks: ["Fresh Linens Kit","AC Comfort"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1495,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'A',
          perks: ["Curtained Berths","Quiet Coach"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 2520,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["First AC Coupe","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_20704',
      trainNumber: '20704',
      trainName: 'Bengaluru - Kacheguda Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      toStation: {"code":"HYB","name":"Hyderabad Deccan Station","city":"Hyderabad","state":"Telangana"},
      departureTime: '02:45 PM',
      arrivalTime: '11:15 PM',
      duration: '8h 30m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 610,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 4,
      highlight: 'Afternoon High-Speed Corridor to the Pearl City',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1540,
          availableSeats: 44,
          status: 'AVAILABLE',
          statusNumber: 44,
          coachCodePrefix: 'C',
          perks: ["High Tea & Hyderabadi Dinner","WiFi","Smooth Ride"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2950,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Chef Dinner","Priority Check-in"]
        }
      ]
    },
    {
      id: 'trn_12786',
      trainNumber: '12786',
      trainName: 'Bengaluru - Kacheguda Superfast',
      trainType: 'Superfast Express',
      fromStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      toStation: {"code":"HYB","name":"Hyderabad Deccan Station","city":"Hyderabad","state":"Telangana"},
      departureTime: '06:20 PM',
      arrivalTime: '05:40 AM',
      duration: '11h 20m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 610,
      rating: 4.65,
      foodIncluded: false,
      haltsCount: 11,
      highlight: 'Smooth Overnight Express reaching Hyderabad before dawn',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 395,
          availableSeats: 82,
          status: 'AVAILABLE',
          statusNumber: 82,
          coachCodePrefix: 'S',
          perks: ["Comfort Berth","Night Lighting"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1045,
          availableSeats: 36,
          status: 'AVAILABLE',
          statusNumber: 36,
          coachCodePrefix: 'B',
          perks: ["Sanitized Linens","AC Comfort"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1495,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'A',
          perks: ["Quiet Berth","Reading Lamp"]
        }
      ]
    },
    {
      id: 'trn_20901',
      trainNumber: '20901',
      trainName: 'Mumbai - Gandhinagar Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      toStation: {"code":"ADI","name":"Ahmedabad Junction","city":"Ahmedabad","state":"Gujarat"},
      departureTime: '06:00 AM',
      arrivalTime: '11:25 AM',
      duration: '5h 25m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 493,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 4,
      highlight: 'Diamond Corridor High-Speed Train reaching 160 km/h with Executive Breakfast',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1320,
          availableSeats: 52,
          status: 'AVAILABLE',
          statusNumber: 52,
          coachCodePrefix: 'C',
          perks: ["Gujarati / Continental Breakfast","WiFi","Infotainment"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2510,
          availableSeats: 18,
          status: 'AVAILABLE',
          statusNumber: 18,
          coachCodePrefix: 'E',
          perks: ["180° Rotating Seats","Executive 3-Course Dining","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_82902',
      trainNumber: '82902',
      trainName: 'Mumbai - Ahmedabad Tejas Express',
      trainType: 'Tejas Express',
      fromStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      toStation: {"code":"ADI","name":"Ahmedabad Junction","city":"Ahmedabad","state":"Gujarat"},
      departureTime: '03:45 PM',
      arrivalTime: '10:05 PM',
      duration: '6h 20m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 493,
      rating: 4.85,
      foodIncluded: true,
      haltsCount: 6,
      highlight: 'Corporate Tejas Express with Flight-Style Hostesses & Smart LCD Screens',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1195,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["High Tea & Dinner Included","Smart Touchscreens"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2350,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["Spacious Recliners","Gourmet Dinner Service","Onboard Lounge"]
        }
      ]
    },
    {
      id: 'trn_12933',
      trainNumber: '12933',
      trainName: 'Karnavati Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      toStation: {"code":"ADI","name":"Ahmedabad Junction","city":"Ahmedabad","state":"Gujarat"},
      departureTime: '01:40 PM',
      arrivalTime: '09:25 PM',
      duration: '7h 45m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 493,
      rating: 4.7,
      foodIncluded: false,
      haltsCount: 8,
      highlight: 'Iconic Afternoon Intercity Corridor connecting Maharashtra & Gujarat',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 690,
          availableSeats: 58,
          status: 'AVAILABLE',
          statusNumber: 58,
          coachCodePrefix: 'C',
          perks: ["Chilled AC Comfort","Pantry Gujarati Farsan"]
        },
        {
          code: 'SL',
          name: 'Second Seating (2S)',
          baseFare: 220,
          availableSeats: 120,
          status: 'AVAILABLE',
          statusNumber: 120,
          coachCodePrefix: 'D',
          perks: ["Reserved Seating","Quick Boarding"]
        }
      ]
    },
    {
      id: 'trn_20902',
      trainNumber: '20902',
      trainName: 'Gandhinagar - Mumbai Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"ADI","name":"Ahmedabad Junction","city":"Ahmedabad","state":"Gujarat"},
      toStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      departureTime: '02:05 PM',
      arrivalTime: '07:35 PM',
      duration: '5h 30m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 493,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 4,
      highlight: 'Fastest Afternoon Transit to Mumbai Financial Capital',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1320,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["Gourmet Evening High Tea & Snacks","WiFi"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2510,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Special Plated Dinner","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12934',
      trainNumber: '12934',
      trainName: 'Karnavati Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"ADI","name":"Ahmedabad Junction","city":"Ahmedabad","state":"Gujarat"},
      toStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      departureTime: '04:55 AM',
      arrivalTime: '12:35 PM',
      duration: '7h 40m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 493,
      rating: 4.7,
      foodIncluded: false,
      haltsCount: 8,
      highlight: 'Popular Morning Business Express into Mumbai',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 690,
          availableSeats: 54,
          status: 'AVAILABLE',
          statusNumber: 54,
          coachCodePrefix: 'C',
          perks: ["AC Seating","Pantry Snacks"]
        },
        {
          code: 'SL',
          name: 'Second Seating (2S)',
          baseFare: 220,
          availableSeats: 110,
          status: 'AVAILABLE',
          statusNumber: 110,
          coachCodePrefix: 'D',
          perks: ["Guaranteed Seat","Affordable Ticket"]
        }
      ]
    },
    {
      id: 'trn_20978',
      trainNumber: '20978',
      trainName: 'Delhi Cantt - Ajmer Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"JP","name":"Jaipur Junction","city":"Jaipur","state":"Rajasthan"},
      departureTime: '06:10 AM',
      arrivalTime: '10:05 AM',
      duration: '3h 55m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 308,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 3,
      highlight: 'High-Speed Luxury Royal Rajputana Corridor with Panoramic Glass',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1050,
          availableSeats: 52,
          status: 'AVAILABLE',
          statusNumber: 52,
          coachCodePrefix: 'C',
          perks: ["Rajasthani Breakfast","WiFi Infotainment","Ergonomic Recline"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 1980,
          availableSeats: 18,
          status: 'AVAILABLE',
          statusNumber: 18,
          coachCodePrefix: 'E',
          perks: ["Rotating Luxury Seats","Royal 3-Course Morning Dining"]
        }
      ]
    },
    {
      id: 'trn_12986',
      trainNumber: '12986',
      trainName: 'Delhi Sarai Rohilla - Jaipur Double Decker',
      trainType: 'Superfast Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"JP","name":"Jaipur Junction","city":"Jaipur","state":"Rajasthan"},
      departureTime: '05:35 PM',
      arrivalTime: '10:05 PM',
      duration: '4h 30m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 308,
      rating: 4.75,
      foodIncluded: false,
      haltsCount: 5,
      highlight: 'Bi-Level Two-Storey High-Capacity AC Express with Elevated Vistas',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 575,
          availableSeats: 88,
          status: 'AVAILABLE',
          statusNumber: 88,
          coachCodePrefix: 'C',
          perks: ["Double Decker Upper Vista","Clean Air Conditioning"]
        }
      ]
    },
    {
      id: 'trn_12015',
      trainNumber: '12015',
      trainName: 'New Delhi - Ajmer Shatabdi',
      trainType: 'Shatabdi Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"JP","name":"Jaipur Junction","city":"Jaipur","state":"Rajasthan"},
      departureTime: '06:10 AM',
      arrivalTime: '10:40 AM',
      duration: '4h 30m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 308,
      rating: 4.8,
      foodIncluded: true,
      haltsCount: 6,
      highlight: 'Heritage Morning Shatabdi with Plated Breakfast & Daily Newspapers',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 885,
          availableSeats: 56,
          status: 'AVAILABLE',
          statusNumber: 56,
          coachCodePrefix: 'C',
          perks: ["Full Breakfast Included","Bottled Mineral Water"]
        },
        {
          code: '1A',
          name: 'Executive Class (EC)',
          baseFare: 1690,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["Spacious 2x2 Seating","Executive Dining Platter"]
        }
      ]
    },
    {
      id: 'trn_20977',
      trainNumber: '20977',
      trainName: 'Ajmer - Delhi Cantt Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"JP","name":"Jaipur Junction","city":"Jaipur","state":"Rajasthan"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '06:00 PM',
      arrivalTime: '10:00 PM',
      duration: '4h 00m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 308,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 3,
      highlight: 'Return Evening High-Speed Corridor from Pink City to Capital',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1050,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["Hot Rajasthani Dinner","WiFi","Quiet Cabin"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 1980,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["Rotating Seats","Special Plated Dinner","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12985',
      trainNumber: '12985',
      trainName: 'Jaipur - Delhi Sarai Rohilla Double Decker',
      trainType: 'Superfast Express',
      fromStation: {"code":"JP","name":"Jaipur Junction","city":"Jaipur","state":"Rajasthan"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '06:00 AM',
      arrivalTime: '10:25 AM',
      duration: '4h 25m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 308,
      rating: 4.75,
      foodIncluded: false,
      haltsCount: 5,
      highlight: 'Morning Double-Decker Express to New Delhi',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 575,
          availableSeats: 84,
          status: 'AVAILABLE',
          statusNumber: 84,
          coachCodePrefix: 'C',
          perks: ["Upper Deck Views","Fast Commute"]
        }
      ]
    },
    {
      id: 'trn_22426',
      trainNumber: '22426',
      trainName: 'New Delhi - Ayodhya Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"LKO","name":"Lucknow Charbagh","city":"Lucknow","state":"Uttar Pradesh"},
      departureTime: '06:10 AM',
      arrivalTime: '12:25 PM',
      duration: '6h 15m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 504,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 2,
      highlight: 'Speedy Express via Kanpur with Automatic Doors & Awadhi Dining',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1395,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["Gourmet Breakfast","WiFi","Ergonomic Recline"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2650,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Awadhi Royal Platter","Priority Check-in"]
        }
      ]
    },
    {
      id: 'trn_82502',
      trainNumber: '82502',
      trainName: 'New Delhi - Lucknow IRCTC Tejas',
      trainType: 'Tejas Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"LKO","name":"Lucknow Charbagh","city":"Lucknow","state":"Uttar Pradesh"},
      departureTime: '03:35 PM',
      arrivalTime: '10:05 PM',
      duration: '6h 30m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 504,
      rating: 4.85,
      foodIncluded: true,
      haltsCount: 3,
      highlight: 'India’s First Privately Operated Luxury Train with Airline Standards',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1280,
          availableSeats: 52,
          status: 'AVAILABLE',
          statusNumber: 52,
          coachCodePrefix: 'C',
          perks: ["Complimentary Snacks & Dinner","Free ₹25L Travel Insurance"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2450,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'E',
          perks: ["Leather Reclining Chairs","Multi-Course Dining","Lounge Access"]
        }
      ]
    },
    {
      id: 'trn_12004',
      trainNumber: '12004',
      trainName: 'Lucknow Shatabdi Express',
      trainType: 'Shatabdi Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"LKO","name":"Lucknow Charbagh","city":"Lucknow","state":"Uttar Pradesh"},
      departureTime: '06:10 AM',
      arrivalTime: '12:40 PM',
      duration: '6h 30m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 504,
      rating: 4.8,
      foodIncluded: true,
      haltsCount: 4,
      highlight: 'Classic Morning Shatabdi with Full Hot Breakfast & Fruit Salad',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1165,
          availableSeats: 56,
          status: 'AVAILABLE',
          statusNumber: 56,
          coachCodePrefix: 'C',
          perks: ["Hot Breakfast Service","Mineral Water"]
        },
        {
          code: '1A',
          name: 'Executive Class (EC)',
          baseFare: 2210,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["Spacious 2x2 Seating","Executive Meal Platter"]
        }
      ]
    },
    {
      id: 'trn_22425',
      trainNumber: '22425',
      trainName: 'Ayodhya - New Delhi Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"LKO","name":"Lucknow Charbagh","city":"Lucknow","state":"Uttar Pradesh"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '03:40 PM',
      arrivalTime: '09:55 PM',
      duration: '6h 15m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 504,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 2,
      highlight: 'Fastest Evening High-Speed Corridor to New Delhi',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1395,
          availableSeats: 46,
          status: 'AVAILABLE',
          statusNumber: 46,
          coachCodePrefix: 'C',
          perks: ["Awadhi Evening Platter & Dinner","WiFi"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2650,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["Rotating Seats","Special Plated Dinner","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_82501',
      trainNumber: '82501',
      trainName: 'Lucknow - New Delhi IRCTC Tejas',
      trainType: 'Tejas Express',
      fromStation: {"code":"LKO","name":"Lucknow Charbagh","city":"Lucknow","state":"Uttar Pradesh"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '06:10 AM',
      arrivalTime: '12:25 PM',
      duration: '6h 15m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 504,
      rating: 4.85,
      foodIncluded: true,
      haltsCount: 3,
      highlight: 'Morning Corporate Flight on Rails with Gourmet Breakfast',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1280,
          availableSeats: 50,
          status: 'AVAILABLE',
          statusNumber: 50,
          coachCodePrefix: 'C',
          perks: ["Fresh Breakfast Included","Touchscreen Infotainment"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2450,
          availableSeats: 15,
          status: 'AVAILABLE',
          statusNumber: 15,
          coachCodePrefix: 'E',
          perks: ["Spacious Recliner","Executive Platter"]
        }
      ]
    },
    {
      id: 'trn_22439',
      trainNumber: '22439',
      trainName: 'Vande Bharat Express (Katra)',
      trainType: 'Vande Bharat',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"SVDK","name":"SMVD Katra","city":"Katra","state":"Jammu & Kashmir"},
      departureTime: '06:00 AM',
      arrivalTime: '02:00 PM',
      duration: '8h 00m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 655,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 3,
      highlight: 'Sacred Pilgrimage High-Speed Express to the Foothills of the Himalayas',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1630,
          availableSeats: 54,
          status: 'AVAILABLE',
          statusNumber: 54,
          coachCodePrefix: 'C',
          perks: ["Pure Vegetarian Gourmet Breakfast","WiFi","Scenic Windows"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 3015,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Satvik Royal Platter","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_22461',
      trainNumber: '22461',
      trainName: 'Shri Shakti AC Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"SVDK","name":"SMVD Katra","city":"Katra","state":"Jammu & Kashmir"},
      departureTime: '07:05 PM',
      arrivalTime: '07:40 AM',
      duration: '12h 35m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 655,
      rating: 4.75,
      foodIncluded: false,
      haltsCount: 6,
      highlight: 'All-AC Premium Pilgrimage Express reaching Katra Base before sunrise',
      classes: [
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1180,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'B',
          perks: ["Sanitized Bedding","AC Comfort","Pantry Service"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1680,
          availableSeats: 18,
          status: 'AVAILABLE',
          statusNumber: 18,
          coachCodePrefix: 'A',
          perks: ["Curtained Privacy","Quiet Berths"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 2840,
          availableSeats: 8,
          status: 'AVAILABLE',
          statusNumber: 8,
          coachCodePrefix: 'H',
          perks: ["First AC Coupe","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_22440',
      trainNumber: '22440',
      trainName: 'Vande Bharat Express (Katra)',
      trainType: 'Vande Bharat',
      fromStation: {"code":"SVDK","name":"SMVD Katra","city":"Katra","state":"Jammu & Kashmir"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '03:00 PM',
      arrivalTime: '11:00 PM',
      duration: '8h 00m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 655,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 3,
      highlight: 'Return High-Speed Express from Katra to New Delhi',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1630,
          availableSeats: 50,
          status: 'AVAILABLE',
          statusNumber: 50,
          coachCodePrefix: 'C',
          perks: ["Pure Veg Dinner","WiFi","Smooth Ride"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 3015,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["Rotating Seats","Special Plated Dinner","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12123',
      trainNumber: '12123',
      trainName: 'Deccan Queen Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      toStation: {"code":"PUNE","name":"Pune Junction","city":"Pune","state":"Maharashtra"},
      departureTime: '05:10 PM',
      arrivalTime: '08:25 PM',
      duration: '3h 15m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 192,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 4,
      highlight: 'Legendary 95-Year-Old Historic Beauty with Onboard Gourmet Dining Car',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 480,
          availableSeats: 58,
          status: 'AVAILABLE',
          statusNumber: 58,
          coachCodePrefix: 'C',
          perks: ["Dining Car Access","Famous Baked Beans & Cutlets"]
        },
        {
          code: 'SL',
          name: 'Second Seating (2S)',
          baseFare: 135,
          availableSeats: 120,
          status: 'AVAILABLE',
          statusNumber: 120,
          coachCodePrefix: 'D',
          perks: ["Reserved Commuter Seat","Punctual Transit"]
        }
      ]
    },
    {
      id: 'trn_22223',
      trainNumber: '22223',
      trainName: 'Mumbai - Solapur Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      toStation: {"code":"PUNE","name":"Pune Junction","city":"Pune","state":"Maharashtra"},
      departureTime: '06:05 AM',
      arrivalTime: '09:15 AM',
      duration: '3h 10m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 192,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 2,
      highlight: 'Ascends Bhor Ghat without Bankers thanks to Twin Traction High Power',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 660,
          availableSeats: 52,
          status: 'AVAILABLE',
          statusNumber: 52,
          coachCodePrefix: 'C',
          perks: ["Maharashtrian Breakfast","Starlink WiFi","Ergonomic Recline"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 1270,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Continental Breakfast","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12125',
      trainNumber: '12125',
      trainName: 'Pragati Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      toStation: {"code":"PUNE","name":"Pune Junction","city":"Pune","state":"Maharashtra"},
      departureTime: '04:25 PM',
      arrivalTime: '07:50 PM',
      duration: '3h 25m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 192,
      rating: 4.75,
      foodIncluded: false,
      haltsCount: 5,
      highlight: 'Modern Vistadome Coach with Glass Dome Roof & 360° Rotating Chairs',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 460,
          availableSeats: 50,
          status: 'AVAILABLE',
          statusNumber: 50,
          coachCodePrefix: 'C',
          perks: ["Air Conditioned","Clean Commuter Seating"]
        },
        {
          code: '1A',
          name: 'Vistadome Glass (EV)',
          baseFare: 990,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'V',
          perks: ["Glass Roof","Observation Lounge","360° Swivel Seats"]
        }
      ]
    },
    {
      id: 'trn_12124',
      trainNumber: '12124',
      trainName: 'Deccan Queen Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"PUNE","name":"Pune Junction","city":"Pune","state":"Maharashtra"},
      toStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      departureTime: '07:15 AM',
      arrivalTime: '10:25 AM',
      duration: '3h 10m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 192,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 4,
      highlight: 'Morning Icon carrying Business Leaders into South Mumbai',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 480,
          availableSeats: 60,
          status: 'AVAILABLE',
          statusNumber: 60,
          coachCodePrefix: 'C',
          perks: ["Heritage Dining Car","Omelette & Toast","Coffee"]
        },
        {
          code: 'SL',
          name: 'Second Seating (2S)',
          baseFare: 135,
          availableSeats: 110,
          status: 'AVAILABLE',
          statusNumber: 110,
          coachCodePrefix: 'D',
          perks: ["Reserved Morning Seat","Quick Transit"]
        }
      ]
    },
    {
      id: 'trn_22224',
      trainNumber: '22224',
      trainName: 'Solapur - Mumbai Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"PUNE","name":"Pune Junction","city":"Pune","state":"Maharashtra"},
      toStation: {"code":"CSMT","name":"Chhatrapati Shivaji Maharaj Terminus","city":"Mumbai","state":"Maharashtra"},
      departureTime: '07:10 PM',
      arrivalTime: '10:25 PM',
      duration: '3h 15m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 192,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 2,
      highlight: 'Evening High-Speed Glide through the Sahyadris into CSMT',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 660,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["Dinner Included","WiFi","Smooth Ride"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 1270,
          availableSeats: 15,
          status: 'AVAILABLE',
          statusNumber: 15,
          coachCodePrefix: 'E',
          perks: ["Rotating Seats","Special Plated Dinner","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12002',
      trainNumber: '12002',
      trainName: 'Bhopal Shatabdi Express',
      trainType: 'Shatabdi Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"BPL","name":"Bhopal Rani Kamlapati","city":"Bhopal","state":"Madhya Pradesh"},
      departureTime: '06:00 AM',
      arrivalTime: '02:40 PM',
      duration: '8h 40m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 701,
      rating: 4.85,
      foodIncluded: true,
      haltsCount: 7,
      highlight: 'Fastest Shatabdi on the Agra High-Speed Corridor running at 150 km/h',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1495,
          availableSeats: 52,
          status: 'AVAILABLE',
          statusNumber: 52,
          coachCodePrefix: 'C',
          perks: ["Breakfast & Lunch Included","Mineral Water"]
        },
        {
          code: '1A',
          name: 'Executive Class (EC)',
          baseFare: 2835,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Executive 3-Course Dining","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_20172',
      trainNumber: '20172',
      trainName: 'Rani Kamlapati - Hazrat Nizamuddin Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"BPL","name":"Bhopal Rani Kamlapati","city":"Bhopal","state":"Madhya Pradesh"},
      departureTime: '02:40 PM',
      arrivalTime: '10:10 PM',
      duration: '7h 30m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 701,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 3,
      highlight: 'Next-Gen High-Speed Link between Capital and Madhya Pradesh',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1735,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["High Tea & Dinner Included","WiFi Infotainment"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 3185,
          availableSeats: 18,
          status: 'AVAILABLE',
          statusNumber: 18,
          coachCodePrefix: 'E',
          perks: ["Rotating Leather Chairs","Gourmet Dining Platter","Priority Access"]
        }
      ]
    },
    {
      id: 'trn_12001',
      trainNumber: '12001',
      trainName: 'Bhopal Shatabdi Express',
      trainType: 'Shatabdi Express',
      fromStation: {"code":"BPL","name":"Bhopal Rani Kamlapati","city":"Bhopal","state":"Madhya Pradesh"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '03:15 PM',
      arrivalTime: '11:50 PM',
      duration: '8h 35m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 701,
      rating: 4.85,
      foodIncluded: true,
      haltsCount: 7,
      highlight: 'Return High-Speed Express to New Delhi with Complimentary Plated Dinner',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1495,
          availableSeats: 46,
          status: 'AVAILABLE',
          statusNumber: 46,
          coachCodePrefix: 'C',
          perks: ["Hot Multi-Course Dinner","Mineral Water"]
        },
        {
          code: '1A',
          name: 'Executive Class (EC)',
          baseFare: 2835,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'E',
          perks: ["Executive Recliner","Multi-Course Dinner"]
        }
      ]
    },
    {
      id: 'trn_12310',
      trainNumber: '12310',
      trainName: 'Patna Tejas Rajdhani Express',
      trainType: 'Rajdhani Superfast',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"PNBE","name":"Patna Junction","city":"Patna","state":"Bihar"},
      departureTime: '05:10 PM',
      arrivalTime: '05:15 AM',
      duration: '12h 05m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1000,
      rating: 4.85,
      foodIncluded: true,
      haltsCount: 5,
      highlight: 'Flagship Overnight Tejas Rajdhani Corridor connecting Capital to Bihar',
      classes: [
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1980,
          availableSeats: 36,
          status: 'AVAILABLE',
          statusNumber: 36,
          coachCodePrefix: 'B',
          perks: ["Dinner & Morning Tea Included","WiFi"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 3040,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'A',
          perks: ["Curtained Berths","Chef-Prepared Meals"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 4680,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["Private Coupe","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_12394',
      trainNumber: '12394',
      trainName: 'Sampoorna Kranti Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"PNBE","name":"Patna Junction","city":"Patna","state":"Bihar"},
      departureTime: '05:30 PM',
      arrivalTime: '06:50 AM',
      duration: '13h 20m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1000,
      rating: 4.75,
      foodIncluded: false,
      haltsCount: 3,
      highlight: 'Legendary Non-Stop Express connecting Delhi to Patna with Minimal Halts',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 510,
          availableSeats: 78,
          status: 'AVAILABLE',
          statusNumber: 78,
          coachCodePrefix: 'S',
          perks: ["Reserved Berth","Pantry Meal Service"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1340,
          availableSeats: 38,
          status: 'AVAILABLE',
          statusNumber: 38,
          coachCodePrefix: 'B',
          perks: ["AC 3-Tier Comfort","Fresh Bedrolls"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1920,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'A',
          perks: ["Curtained Berths","Quiet Coach"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 3240,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["First AC Coupe","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_12309',
      trainNumber: '12309',
      trainName: 'Patna Tejas Rajdhani Express',
      trainType: 'Rajdhani Superfast',
      fromStation: {"code":"PNBE","name":"Patna Junction","city":"Patna","state":"Bihar"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '07:25 PM',
      arrivalTime: '07:40 AM',
      duration: '12h 15m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1000,
      rating: 4.85,
      foodIncluded: true,
      haltsCount: 5,
      highlight: 'Return Premier High-Speed Overnight Journey to New Delhi',
      classes: [
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1980,
          availableSeats: 34,
          status: 'AVAILABLE',
          statusNumber: 34,
          coachCodePrefix: 'B',
          perks: ["Complimentary Dinner & Morning Tea","WiFi"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 3040,
          availableSeats: 15,
          status: 'AVAILABLE',
          statusNumber: 15,
          coachCodePrefix: 'A',
          perks: ["Curtained Luxury","Warm Meals"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 4680,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["Private Coupe","Butler Service"]
        }
      ]
    },
    {
      id: 'trn_12393',
      trainNumber: '12393',
      trainName: 'Sampoorna Kranti Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"PNBE","name":"Patna Junction","city":"Patna","state":"Bihar"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '07:25 PM',
      arrivalTime: '07:55 AM',
      duration: '12h 30m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 1000,
      rating: 4.75,
      foodIncluded: false,
      haltsCount: 3,
      highlight: 'Punctual Overnight Superfast to New Delhi with Fast Transit via Kanpur',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 510,
          availableSeats: 72,
          status: 'AVAILABLE',
          statusNumber: 72,
          coachCodePrefix: 'S',
          perks: ["Reserved Berth","Pantry Service"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1340,
          availableSeats: 35,
          status: 'AVAILABLE',
          statusNumber: 35,
          coachCodePrefix: 'B',
          perks: ["Sanitized Linens","AC Comfort"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1920,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'A',
          perks: ["Quiet Berths","Reading Lights"]
        }
      ]
    },
    {
      id: 'trn_12013',
      trainNumber: '12013',
      trainName: 'Amritsar Shatabdi Express',
      trainType: 'Shatabdi Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"ASR","name":"Amritsar Junction","city":"Amritsar","state":"Punjab"},
      departureTime: '04:30 PM',
      arrivalTime: '10:30 PM',
      duration: '6h 00m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 448,
      rating: 4.8,
      foodIncluded: true,
      haltsCount: 6,
      highlight: 'Evening High-Speed Shatabdi to the Golden Temple City with Plated Dinner',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1060,
          availableSeats: 52,
          status: 'AVAILABLE',
          statusNumber: 52,
          coachCodePrefix: 'C',
          perks: ["Punjabi Cuisine Dinner","Mineral Water"]
        },
        {
          code: '1A',
          name: 'Executive Class (EC)',
          baseFare: 2010,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["Spacious Recliner","Executive Dinner Platter"]
        }
      ]
    },
    {
      id: 'trn_12497',
      trainNumber: '12497',
      trainName: 'Shan-e-Punjab Superfast',
      trainType: 'Superfast Express',
      fromStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      toStation: {"code":"ASR","name":"Amritsar Junction","city":"Amritsar","state":"Punjab"},
      departureTime: '06:40 AM',
      arrivalTime: '02:15 PM',
      duration: '7h 35m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 448,
      rating: 4.7,
      foodIncluded: false,
      haltsCount: 12,
      highlight: 'Daytime Pride of Punjab with Reserved Seating & Scenic Mustard Fields',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 640,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["AC Seating","Pantry Snacks"]
        },
        {
          code: 'SL',
          name: 'Second Seating (2S)',
          baseFare: 195,
          availableSeats: 110,
          status: 'AVAILABLE',
          statusNumber: 110,
          coachCodePrefix: 'D',
          perks: ["Reserved Seat","Affordable Commute"]
        }
      ]
    },
    {
      id: 'trn_12014',
      trainNumber: '12014',
      trainName: 'Amritsar Shatabdi Express',
      trainType: 'Shatabdi Express',
      fromStation: {"code":"ASR","name":"Amritsar Junction","city":"Amritsar","state":"Punjab"},
      toStation: {"code":"NDLS","name":"New Delhi Railway Station","city":"New Delhi","state":"Delhi"},
      departureTime: '04:55 AM',
      arrivalTime: '11:02 AM',
      duration: '6h 07m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 448,
      rating: 4.8,
      foodIncluded: true,
      haltsCount: 6,
      highlight: 'Morning High-Speed Shatabdi to Capital with Full Breakfast Service',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1060,
          availableSeats: 50,
          status: 'AVAILABLE',
          statusNumber: 50,
          coachCodePrefix: 'C',
          perks: ["Breakfast Included","Bottled Water"]
        },
        {
          code: '1A',
          name: 'Executive Class (EC)',
          baseFare: 2010,
          availableSeats: 15,
          status: 'AVAILABLE',
          statusNumber: 15,
          coachCodePrefix: 'E',
          perks: ["Executive Recliner","Breakfast Platter"]
        }
      ]
    },
    {
      id: 'trn_20641',
      trainNumber: '20641',
      trainName: 'Bengaluru - Ernakulam Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      toStation: {"code":"ERS","name":"Ernakulam Junction","city":"Kochi","state":"Kerala"},
      departureTime: '05:30 AM',
      arrivalTime: '01:50 PM',
      duration: '8h 20m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 585,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 6,
      highlight: 'Majestic Kerala Express traversing Western Ghats with Kerala Feast Catering',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1465,
          availableSeats: 52,
          status: 'AVAILABLE',
          statusNumber: 52,
          coachCodePrefix: 'C',
          perks: ["Kerala Style Breakfast & Lunch","WiFi Infotainment"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2810,
          availableSeats: 18,
          status: 'AVAILABLE',
          statusNumber: 18,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Curated South Indian Platter","Priority Access"]
        }
      ]
    },
    {
      id: 'trn_16526',
      trainNumber: '16526',
      trainName: 'Kanyakumari Island Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      toStation: {"code":"ERS","name":"Ernakulam Junction","city":"Kochi","state":"Kerala"},
      departureTime: '08:10 PM',
      arrivalTime: '07:15 AM',
      duration: '11h 05m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 585,
      rating: 4.6,
      foodIncluded: false,
      haltsCount: 16,
      highlight: 'Beloved Overnight Train Connecting Karnataka to God’s Own Country',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 360,
          availableSeats: 84,
          status: 'AVAILABLE',
          statusNumber: 84,
          coachCodePrefix: 'S',
          perks: ["Reserved Berth","Night Lighting"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 980,
          availableSeats: 36,
          status: 'AVAILABLE',
          statusNumber: 36,
          coachCodePrefix: 'B',
          perks: ["Clean Bedrolls","Air Conditioned"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1410,
          availableSeats: 14,
          status: 'AVAILABLE',
          statusNumber: 14,
          coachCodePrefix: 'A',
          perks: ["Curtained Privacy","Quiet Coach"]
        }
      ]
    },
    {
      id: 'trn_20642',
      trainNumber: '20642',
      trainName: 'Ernakulam - Bengaluru Vande Bharat',
      trainType: 'Vande Bharat',
      fromStation: {"code":"ERS","name":"Ernakulam Junction","city":"Kochi","state":"Kerala"},
      toStation: {"code":"SBC","name":"KSR Bengaluru City","city":"Bengaluru","state":"Karnataka"},
      departureTime: '02:30 PM',
      arrivalTime: '10:50 PM',
      duration: '8h 20m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 585,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 6,
      highlight: 'Afternoon High-Speed Corridor to Bengaluru IT Hub',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1465,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["High Tea & Dinner Included","WiFi"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2810,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["Rotating Seats","Special Plated Dinner","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12760',
      trainNumber: '12760',
      trainName: 'Charminar Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"HYB","name":"Hyderabad Deccan Station","city":"Hyderabad","state":"Telangana"},
      toStation: {"code":"MAS","name":"MGR Chennai Central","city":"Chennai","state":"Tamil Nadu"},
      departureTime: '06:00 PM',
      arrivalTime: '07:00 AM',
      duration: '13h 00m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 715,
      rating: 4.75,
      foodIncluded: false,
      haltsCount: 14,
      highlight: 'Iconic Grand Trunk Express connecting Hyderabad Deccan to Chennai Central',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 410,
          availableSeats: 78,
          status: 'AVAILABLE',
          statusNumber: 78,
          coachCodePrefix: 'S',
          perks: ["Comfortable Berth","Night Quiet Hours"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1090,
          availableSeats: 36,
          status: 'AVAILABLE',
          statusNumber: 36,
          coachCodePrefix: 'B',
          perks: ["AC 3-Tier Comfort","Fresh Bedding Kit"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1560,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'A',
          perks: ["Curtained Berths","Quiet Coach"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 2620,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["First AC Coupe","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_20678',
      trainNumber: '20678',
      trainName: 'Vande Bharat Express (Chennai)',
      trainType: 'Vande Bharat',
      fromStation: {"code":"HYB","name":"Hyderabad Deccan Station","city":"Hyderabad","state":"Telangana"},
      toStation: {"code":"MAS","name":"MGR Chennai Central","city":"Chennai","state":"Tamil Nadu"},
      departureTime: '06:15 AM',
      arrivalTime: '01:50 PM',
      duration: '7h 35m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 715,
      rating: 4.9,
      foodIncluded: true,
      haltsCount: 4,
      highlight: 'Morning High-Speed Link connecting Telangana and Tamil Nadu',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1620,
          availableSeats: 52,
          status: 'AVAILABLE',
          statusNumber: 52,
          coachCodePrefix: 'C',
          perks: ["Breakfast & Lunch Included","WiFi"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 3080,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["180° Swivel Seats","Chef-Curated Meals","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12759',
      trainNumber: '12759',
      trainName: 'Charminar Superfast Express',
      trainType: 'Superfast Express',
      fromStation: {"code":"MAS","name":"MGR Chennai Central","city":"Chennai","state":"Tamil Nadu"},
      toStation: {"code":"HYB","name":"Hyderabad Deccan Station","city":"Hyderabad","state":"Telangana"},
      departureTime: '06:10 PM',
      arrivalTime: '07:15 AM',
      duration: '13h 05m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 715,
      rating: 4.75,
      foodIncluded: false,
      haltsCount: 14,
      highlight: 'Return Night Express from Chennai Central to Hyderabad',
      classes: [
        {
          code: 'SL',
          name: 'Sleeper Class (SL)',
          baseFare: 410,
          availableSeats: 75,
          status: 'AVAILABLE',
          statusNumber: 75,
          coachCodePrefix: 'S',
          perks: ["Reserved Berth","Night Lighting"]
        },
        {
          code: '3A',
          name: 'AC 3 Tier (3A)',
          baseFare: 1090,
          availableSeats: 34,
          status: 'AVAILABLE',
          statusNumber: 34,
          coachCodePrefix: 'B',
          perks: ["Sanitized Linens","AC Comfort"]
        },
        {
          code: '2A',
          name: 'AC 2 Tier (2A)',
          baseFare: 1560,
          availableSeats: 15,
          status: 'AVAILABLE',
          statusNumber: 15,
          coachCodePrefix: 'A',
          perks: ["Curtained Privacy","Quiet Berths"]
        },
        {
          code: '1A',
          name: 'First AC (1A)',
          baseFare: 2620,
          availableSeats: 6,
          status: 'AVAILABLE',
          statusNumber: 6,
          coachCodePrefix: 'H',
          perks: ["Private Coupe","Personal Attendant"]
        }
      ]
    },
    {
      id: 'trn_22348',
      trainNumber: '22348',
      trainName: 'Howrah - Patna Vande Bharat Express',
      trainType: 'Vande Bharat',
      fromStation: {"code":"HWH","name":"Howrah Junction","city":"Kolkata","state":"West Bengal"},
      toStation: {"code":"PNBE","name":"Patna Junction","city":"Patna","state":"Bihar"},
      departureTime: '03:50 PM',
      arrivalTime: '10:40 PM',
      duration: '6h 50m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 532,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 6,
      highlight: 'High-Speed Evening Corridor connecting West Bengal with Bihar Capital',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1450,
          availableSeats: 50,
          status: 'AVAILABLE',
          statusNumber: 50,
          coachCodePrefix: 'C',
          perks: ["High Tea & Dinner Included","WiFi Infotainment"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2750,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["180° Rotating Seats","Plated Dinner","Priority Boarding"]
        }
      ]
    },
    {
      id: 'trn_12023',
      trainNumber: '12023',
      trainName: 'Howrah - Patna Jan Shatabdi',
      trainType: 'Jan Shatabdi',
      fromStation: {"code":"HWH","name":"Howrah Junction","city":"Kolkata","state":"West Bengal"},
      toStation: {"code":"PNBE","name":"Patna Junction","city":"Patna","state":"Bihar"},
      departureTime: '02:05 PM',
      arrivalTime: '10:25 PM',
      duration: '8h 20m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 532,
      rating: 4.7,
      foodIncluded: false,
      haltsCount: 11,
      highlight: 'Affordable High-Speed Day Intercity with AC & Second Seating Options',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 735,
          availableSeats: 46,
          status: 'AVAILABLE',
          statusNumber: 46,
          coachCodePrefix: 'C',
          perks: ["Air Conditioned Seating","Pantry Snacks"]
        },
        {
          code: 'SL',
          name: 'Second Seating (2S)',
          baseFare: 230,
          availableSeats: 115,
          status: 'AVAILABLE',
          statusNumber: 115,
          coachCodePrefix: 'D',
          perks: ["Reserved Seat","Affordable Ticket"]
        }
      ]
    },
    {
      id: 'trn_22347',
      trainNumber: '22347',
      trainName: 'Patna - Howrah Vande Bharat Express',
      trainType: 'Vande Bharat',
      fromStation: {"code":"PNBE","name":"Patna Junction","city":"Patna","state":"Bihar"},
      toStation: {"code":"HWH","name":"Howrah Junction","city":"Kolkata","state":"West Bengal"},
      departureTime: '08:00 AM',
      arrivalTime: '02:35 PM',
      duration: '6h 35m',
      runsOn: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      distanceKm: 532,
      rating: 4.95,
      foodIncluded: true,
      haltsCount: 6,
      highlight: 'Morning High-Speed Bullet Profile Express to Howrah',
      classes: [
        {
          code: '3A',
          name: 'AC Chair Car (CC)',
          baseFare: 1450,
          availableSeats: 48,
          status: 'AVAILABLE',
          statusNumber: 48,
          coachCodePrefix: 'C',
          perks: ["Breakfast & Lunch Included","WiFi"]
        },
        {
          code: '1A',
          name: 'Executive Chair Car (EC)',
          baseFare: 2750,
          availableSeats: 16,
          status: 'AVAILABLE',
          statusNumber: 16,
          coachCodePrefix: 'E',
          perks: ["Rotating Seats","Special Plated Lunch","Priority Check-in"]
        }
      ]
    }
  ];

  getStations(): Station[] {
    return [...this.stations];
  }

  getStationByCode(code: string): Station | undefined {
    return this.stations.find(s => s.code.toUpperCase() === code.toUpperCase());
  }

  getAllTrains(): Train[] {
    return [...this.primaryTrains];
  }

  getTrainById(id: string): Train | undefined {
    // 1. Direct match in primary inventory
    const direct = this.primaryTrains.find(t => t.id === id);
    if (direct) return direct;

    // 2. Check storage for dynamically scheduled train
    const dyn = sessionStorage.getItem('dyn_train_' + id) || localStorage.getItem('dyn_train_' + id);
    if (dyn) {
      try {
        return JSON.parse(dyn);
      } catch {
        // Fallback below
      }
    }

    // 3. Fallback deterministic reconstruction for deep-links or after cache clear
    const match = id.match(/trn_([A-Z0-9]+)/);
    if (match) {
      const trainNum = match[1];
      const defaultTrain: Train = {
        id: id,
        trainNumber: trainNum,
        trainName: `LumaRail Express #${trainNum}`,
        trainType: 'Superfast Express',
        fromStation: this.stations[0],
        toStation: this.stations[1],
        departureTime: '08:30 AM',
        arrivalTime: '06:45 PM',
        duration: '10h 15m',
        runsOn: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        distanceKm: 780,
        rating: 4.8,
        foodIncluded: true,
        haltsCount: 6,
        highlight: 'Premier High-Speed Scheduled Corridor with Air-Conditioned Comfort',
        classes: [
          { code: 'SL', name: 'Sleeper Class (SL)', baseFare: 480, availableSeats: 58, status: 'AVAILABLE', statusNumber: 58, coachCodePrefix: 'S', perks: ['Comfort Berth', 'Pantry Service'] },
          { code: '3A', name: 'AC 3 Tier (3A)', baseFare: 1260, availableSeats: 32, status: 'AVAILABLE', statusNumber: 32, coachCodePrefix: 'B', perks: ['Fresh Bedding Kit', 'Mobile Charging'] },
          { code: '2A', name: 'AC 2 Tier (2A)', baseFare: 1780, availableSeats: 14, status: 'AVAILABLE', statusNumber: 14, coachCodePrefix: 'A', perks: ['Curtained Privacy', 'Quiet Coach'] },
          { code: '1A', name: 'First AC (1A)', baseFare: 2950, availableSeats: 6, status: 'AVAILABLE', statusNumber: 6, coachCodePrefix: 'H', perks: ['Private Coupe', 'Personal Attendant'] }
        ]
      };
      return defaultTrain;
    }

    return undefined;
  }

  /**
   * Search trains between two stations.
   * Ensures that EVERY route search returns 5 to 8 realistic, varied departure options
   * across different times of day (morning, afternoon, evening, night).
   */
  searchTrains(fromCode: string, toCode: string, travelClass?: string): Train[] {
    const fromUpper = fromCode.trim().toUpperCase();
    const toUpper = toCode.trim().toUpperCase();

    // 1. Direct matches in primary train inventory
    let matches = this.primaryTrains.filter(t => 
      t.fromStation.code.toUpperCase() === fromUpper && 
      t.toStation.code.toUpperCase() === toUpper
    );

    // 2. High-Frequency Supplemental Scheduler:
    // If fewer than 6 trains exist, generate supplemental scheduled trains
    // so every search displays 6 to 8 varied departure times!
    const fromSt = this.getStationByCode(fromUpper);
    const toSt = this.getStationByCode(toUpper);

    if (fromSt && toSt && fromSt.code !== toSt.code) {
      const targetCount = 6;
      if (matches.length < targetCount) {
        const extra = this.generateSupplementalSchedules(fromSt, toSt, targetCount - matches.length, matches.length);
        matches = [...matches, ...extra];
      }
    }

    // Filter by travel class if specified and not 'ALL'
    if (travelClass && travelClass !== 'ALL') {
      matches = matches.filter(t => t.classes.some(c => c.code === travelClass));
    }

    return matches;
  }

  /**
   * Generates realistic, varied scheduled trains across departure windows
   * (morning, mid-day, afternoon, evening, night, late night).
   */
  private generateSupplementalSchedules(from: Station, to: Station, count: number, offset: number): Train[] {
    const hash = (from.code + to.code).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const results: Train[] = [];

    const scheduleTemplates = [
      {
        type: 'Vande Bharat' as const,
        dep: '06:00 AM', arr: '01:45 PM', dur: '7h 45m', halts: 4,
        prefix: 'Vande Bharat Bullet', rating: 4.95, food: true, bFare: 1650,
        hl: 'Next-Gen High-Speed Aero-Dynamic Transit with WiFi & Breakfast'
      },
      {
        type: 'Shatabdi Express' as const,
        dep: '07:30 AM', arr: '02:00 PM', dur: '6h 30m', halts: 5,
        prefix: 'Morning Shatabdi', rating: 4.8, food: true, bFare: 1120,
        hl: 'Executive Day Commuter with Full Complimentary Breakfast & Fruit Salad'
      },
      {
        type: 'Jan Shatabdi' as const,
        dep: '10:15 AM', arr: '05:45 PM', dur: '7h 30m', halts: 8,
        prefix: 'Jan Shatabdi Express', rating: 4.65, food: false, bFare: 740,
        hl: 'Reliable Daytime Intercity with AC Seating and Scenic Panoramic Windows'
      },
      {
        type: 'Tejas Express' as const,
        dep: '02:45 PM', arr: '09:30 PM', dur: '6h 45m', halts: 4,
        prefix: 'Corporate Tejas Express', rating: 4.85, food: true, bFare: 1820,
        hl: 'Luxury High-Speed Smart Coach with Touchscreen Infotainment & High Tea'
      },
      {
        type: 'Rajdhani Superfast' as const,
        dep: '05:15 PM', arr: '08:45 AM', dur: '15h 30m', halts: 6,
        prefix: 'Tejas Rajdhani Express', rating: 4.9, food: true, bFare: 2280,
        hl: 'Premier High-Speed Overnight Flagship with Multi-Course Dinner & Linens'
      },
      {
        type: 'Duronto Superfast' as const,
        dep: '07:20 PM', arr: '08:15 AM', dur: '12h 55m', halts: 3,
        prefix: 'Non-Stop Duronto Express', rating: 4.75, food: true, bFare: 1940,
        hl: 'Point-to-Point Non-Stop Express with Priority Track Clearance'
      },
      {
        type: 'Superfast Express' as const,
        dep: '08:45 PM', arr: '07:30 AM', dur: '10h 45m', halts: 10,
        prefix: 'Royal Superfast Mail', rating: 4.7, food: false, bFare: 520,
        hl: 'Overnight Sleeper Express with Clean Bedrolls & Quiet Quiet Hours'
      },
      {
        type: 'Garib Rath' as const,
        dep: '10:30 PM', arr: '09:15 AM', dur: '10h 45m', halts: 7,
        prefix: 'All-AC Garib Rath Express', rating: 4.6, food: false, bFare: 890,
        hl: 'Affordable Full-AC Overnight Travel with Clean Linens & Mobile Charging'
      }
    ];

    for (let i = 0; i < count; i++) {
      const idx = (offset + i) % scheduleTemplates.length;
      const sch = scheduleTemplates[idx];
      const trainNum = (12000 + ((hash * 17 + (offset + i) * 313) % 10990)).toString();

      const synthTrain: Train = {
        id: `trn_${trainNum}`,
        trainNumber: trainNum,
        trainName: `${from.city} - ${to.city} ${sch.prefix}`,
        trainType: sch.type,
        fromStation: from,
        toStation: to,
        departureTime: sch.dep,
        arrivalTime: sch.arr,
        duration: sch.dur,
        runsOn: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        distanceKm: 550 + ((hash * (i + 1)) % 650),
        rating: sch.rating,
        foodIncluded: sch.food,
        haltsCount: sch.halts,
        highlight: sch.hl,
        classes: [
          {
            code: 'SL',
            name: 'Sleeper Class (SL)',
            baseFare: sch.bFare > 1000 ? Math.round(sch.bFare * 0.35) : sch.bFare,
            availableSeats: 64 - (i * 6),
            status: 'AVAILABLE',
            statusNumber: 64 - (i * 6),
            coachCodePrefix: 'S',
            perks: ['Budget Reserved Seat', 'Clean Berths', 'Pantry Service']
          },
          {
            code: '3A',
            name: 'AC 3 Tier (3A)',
            baseFare: sch.bFare,
            availableSeats: 32 + (i * 4),
            status: 'AVAILABLE',
            statusNumber: 32 + (i * 4),
            coachCodePrefix: 'B',
            perks: ['Air Conditioned', 'Bedding Kit', 'Mobile Charging']
          },
          {
            code: '2A',
            name: 'AC 2 Tier (2A)',
            baseFare: Math.round(sch.bFare * 1.55),
            availableSeats: 16 - i,
            status: (16 - i) > 5 ? 'AVAILABLE' : 'RAC',
            statusNumber: 16 - i,
            coachCodePrefix: 'A',
            perks: ['Spacious 2x2 Berth', 'Curtained Privacy', 'Quiet Coach']
          },
          {
            code: '1A',
            name: 'First AC (1A)',
            baseFare: Math.round(sch.bFare * 2.5),
            availableSeats: 6,
            status: 'AVAILABLE',
            statusNumber: 6,
            coachCodePrefix: 'H',
            perks: ['Private Coupe', 'Personal Attendant', 'Complimentary Refreshments']
          }
        ]
      };

      // Cache into both session and local storage for cross-page persistence
      try {
        sessionStorage.setItem('dyn_train_' + synthTrain.id, JSON.stringify(synthTrain));
        localStorage.setItem('dyn_train_' + synthTrain.id, JSON.stringify(synthTrain));
      } catch {
        // Storage full or unavailable in test
      }

      results.push(synthTrain);
    }

    return results;
  }
}
