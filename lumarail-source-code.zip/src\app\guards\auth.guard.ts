import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { NotificationService } from '../services/notification.service';

export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  const notificationService = inject(NotificationService);

  if (authService.isLoggedIn()) {
    return true;
  }

  notificationService.warning('Please sign in to proceed with your booking.', 'Authentication Required');
  router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
  return false;
};
