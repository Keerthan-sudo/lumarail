import { Injectable, signal } from '@angular/core';
import { Booking, FareBreakdown, PassengerDetail } from '../models/booking.model';
import { Train, TrainClass } from '../models/train.model';
import { User } from '../models/user.model';
import { NotificationService } from './notification.service';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private readonly BOOKINGS_KEY = 'lumarail_bookings';

  // Reactive signal for bookings count or updates
  bookingsUpdated = signal<number>(Date.now());

  constructor(private notificationService: NotificationService) {
    this.seedDefaultBookings();
  }

  private seedDefaultBookings(): void {
    const existing = localStorage.getItem(this.BOOKINGS_KEY);
    if (!existing) {
      const demoBookings: Booking[] = [
        {
          id: 'bkg_sample_1',
          pnr: 'LUM-8924-X91',
          userId: 'usr_demo_101',
          userEmail: 'student@lumarail.com',
          userName: 'Vikramaditya Roy',
          userPhone: '9876543210',
          trainId: 'trn_22436',
          trainNumber: '22436',
          trainName: 'Vande Bharat Express',
          trainType: 'Vande Bharat',
          fromStation: { code: 'NDLS', name: 'New Delhi Railway Station', city: 'New Delhi', state: 'Delhi' },
          toStation: { code: 'BSB', name: 'Varanasi Junction', city: 'Varanasi', state: 'Uttar Pradesh' },
          journeyDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
          departureTime: '06:00 AM',
          arrivalTime: '02:00 PM',
          duration: '8h 00m',
          selectedClass: '1A',
          className: 'Executive Chair Car (EC)',
          passengers: [
            {
              id: 'p_1',
              name: 'Vikramaditya Roy',
              age: 23,
              gender: 'Male',
              berthPreference: 'Window',
              assignedCoach: 'E1',
              assignedSeat: '12 (W)',
              status: 'CONFIRMED'
            },
            {
              id: 'p_2',
              name: 'Ananya Sharma',
              age: 22,
              gender: 'Female',
              berthPreference: 'Window',
              assignedCoach: 'E1',
              assignedSeat: '13 (Aisle)',
              status: 'CONFIRMED'
            }
          ],
          fareBreakdown: {
            baseFarePerPerson: 3300,
            passengerCount: 2,
            subTotal: 6600,
            reservationFee: 80,
            superfastCharge: 90,
            gstAmount: 330,
            totalFare: 7100
          },
          status: 'CONFIRMED',
          chartStatus: 'CHART PREPARED',
          bookingDate: new Date(Date.now() - 86400000).toISOString()
        },
        {
          id: 'bkg_sample_2',
          pnr: 'LUM-4102-K55',
          userId: 'usr_demo_101',
          userEmail: 'student@lumarail.com',
          userName: 'Vikramaditya Roy',
          userPhone: '9876543210',
          trainId: 'trn_22229',
          trainNumber: '22229',
          trainName: 'Konkan Vista Vande Bharat',
          trainType: 'Vande Bharat',
          fromStation: { code: 'CSMT', name: 'Chhatrapati Shivaji Maharaj Terminus', city: 'Mumbai', state: 'Maharashtra' },
          toStation: { code: 'MAO', name: 'Madgaon Junction Goa', city: 'Goa', state: 'Goa' },
          journeyDate: new Date(Date.now() + 86400000 * 7).toISOString().split('T')[0],
          departureTime: '05:25 AM',
          arrivalTime: '01:10 PM',
          duration: '7h 45m',
          selectedClass: '3A',
          className: 'AC Chair Car (CC)',
          passengers: [
            {
              id: 'p_3',
              name: 'Vikramaditya Roy',
              age: 23,
              gender: 'Male',
              berthPreference: 'Window',
              assignedCoach: 'C3',
              assignedSeat: '45 (W)',
              status: 'CONFIRMED'
            }
          ],
          fareBreakdown: {
            baseFarePerPerson: 1815,
            passengerCount: 1,
            subTotal: 1815,
            reservationFee: 40,
            superfastCharge: 45,
            gstAmount: 91,
            totalFare: 1991
          },
          status: 'CONFIRMED',
          chartStatus: 'CHART NOT PREPARED',
          bookingDate: new Date(Date.now() - 86400000 * 2).toISOString()
        }
      ];

      localStorage.setItem(this.BOOKINGS_KEY, JSON.stringify(demoBookings));
    }
  }

  getAllBookings(): Booking[] {
    try {
      const data = localStorage.getItem(this.BOOKINGS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  getUserBookings(userId: string, userEmail?: string): Booking[] {
    const all = this.getAllBookings();
    return all.filter(b => 
      b.userId === userId || 
      (userEmail && (
        b.userEmail.toLowerCase() === userEmail.toLowerCase() ||
        (userEmail.toLowerCase().includes('student@') && b.userEmail.toLowerCase().includes('student@'))
      ))
    );
  }

  getBookingByPNR(pnrQuery: string): Booking | undefined {
    if (!pnrQuery) return undefined;
    const cleanPNR = pnrQuery.trim().replace(/-/g, '').toUpperCase();
    const all = this.getAllBookings();
    
    return all.find(b => {
      const storedClean = b.pnr.replace(/-/g, '').toUpperCase();
      return storedClean === cleanPNR || b.pnr.toUpperCase() === pnrQuery.trim().toUpperCase();
    });
  }

  calculateFare(baseFare: number, count: number): FareBreakdown {
    const subTotal = baseFare * count;
    const reservationFee = 40 * count;
    const superfastCharge = 45 * count;
    const gstAmount = Math.round(subTotal * 0.05);
    const totalFare = subTotal + reservationFee + superfastCharge + gstAmount;

    return {
      baseFarePerPerson: baseFare,
      passengerCount: count,
      subTotal,
      reservationFee,
      superfastCharge,
      gstAmount,
      totalFare
    };
  }

  generatePNR(): string {
    const randomDigits = Math.floor(1000 + Math.random() * 9000);
    const randomChar = String.fromCharCode(65 + Math.floor(Math.random() * 26));
    const randomSuffix = Math.floor(10 + Math.random() * 90);
    return `LUM-${randomDigits}-${randomChar}${randomSuffix}`;
  }

  allocateBerths(passengers: { name: string; age: number; gender: string; berthPreference: string }[], trainClass: TrainClass): PassengerDetail[] {
    const coachPrefix = trainClass.coachCodePrefix || 'B';
    const coachNum = Math.floor(1 + Math.random() * 3);
    const assignedCoach = `${coachPrefix}${coachNum}`;

    let baseSeat = 18 + Math.floor(Math.random() * 30);

    return passengers.map((p, index) => {
      const seatNo = baseSeat + index;
      let berthType = p.berthPreference;

      if (!berthType || berthType === 'No Preference') {
        const types = ['LB', 'MB', 'UB', 'SL', 'SU'];
        berthType = types[index % types.length];
      } else {
        if (berthType === 'Lower') berthType = 'LB';
        else if (berthType === 'Middle') berthType = 'MB';
        else if (berthType === 'Upper') berthType = 'UB';
        else if (berthType === 'Side Lower') berthType = 'SL';
        else if (berthType === 'Side Upper') berthType = 'SU';
        else if (berthType === 'Window') berthType = 'W';
      }

      return {
        id: 'psg_' + Math.random().toString(36).substring(2, 8),
        name: p.name.trim(),
        age: Number(p.age),
        gender: p.gender as any,
        berthPreference: p.berthPreference as any,
        assignedCoach,
        assignedSeat: `${seatNo} (${berthType})`,
        status: 'CONFIRMED'
      };
    });
  }

  createBooking(
    user: User,
    train: Train,
    trainClass: TrainClass,
    journeyDate: string,
    rawPassengers: { name: string; age: number; gender: string; berthPreference: string }[],
    contactPhone: string,
    contactEmail: string
  ): Booking {
    const pnr = this.generatePNR();
    const passengers = this.allocateBerths(rawPassengers, trainClass);
    const fareBreakdown = this.calculateFare(trainClass.baseFare, rawPassengers.length);

    const newBooking: Booking = {
      id: 'bkg_' + Date.now().toString(36),
      pnr,
      userId: user.id,
      userEmail: contactEmail || user.email,
      userName: user.name,
      userPhone: contactPhone || user.phone,
      trainId: train.id,
      trainNumber: train.trainNumber,
      trainName: train.trainName,
      trainType: train.trainType,
      fromStation: train.fromStation,
      toStation: train.toStation,
      journeyDate,
      departureTime: train.departureTime,
      arrivalTime: train.arrivalTime,
      duration: train.duration,
      selectedClass: trainClass.code,
      className: trainClass.name,
      passengers,
      fareBreakdown,
      status: 'CONFIRMED',
      chartStatus: 'CHART PREPARED',
      bookingDate: new Date().toISOString()
    };

    const all = this.getAllBookings();
    all.unshift(newBooking);
    localStorage.setItem(this.BOOKINGS_KEY, JSON.stringify(all));

    this.bookingsUpdated.set(Date.now());
    this.notificationService.success(`Booking Confirmed! PNR: ${pnr}`, 'Ticket Issued');
    return newBooking;
  }

  cancelBooking(bookingId: string): { success: boolean; refundAmount: number; message: string } {
    const all = this.getAllBookings();
    const index = all.findIndex(b => b.id === bookingId);

    if (index === -1) {
      return { success: false, refundAmount: 0, message: 'Booking not found.' };
    }

    const booking = all[index];
    if (booking.status === 'CANCELLED') {
      return { success: false, refundAmount: 0, message: 'Ticket has already been cancelled.' };
    }

    // Standard cancellation fee: ₹120 per passenger
    const cancelFeePerPassenger = 120;
    const totalFee = cancelFeePerPassenger * booking.passengers.length;
    const refund = Math.max(0, booking.fareBreakdown.totalFare - totalFee);

    booking.status = 'CANCELLED';
    booking.cancellationDate = new Date().toISOString();
    booking.refundAmount = refund;

    booking.passengers.forEach(p => {
      p.status = 'WL';
    });

    all[index] = booking;
    localStorage.setItem(this.BOOKINGS_KEY, JSON.stringify(all));

    this.bookingsUpdated.set(Date.now());
    this.notificationService.info(`Ticket with PNR ${booking.pnr} cancelled. Refund of ₹${refund} initiated.`, 'Cancellation Processed');

    return { success: true, refundAmount: refund, message: 'Ticket cancelled successfully.' };
  }
}
