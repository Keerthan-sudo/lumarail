import { Injectable, signal } from '@angular/core';

export type SupportedLanguage = 'en' | 'te' | 'hi';

export interface LanguageOption {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  flag: string;
}

@Injectable({
  providedIn: 'root'
})
export class I18nService {
  private readonly STORAGE_KEY = 'lumarail_lang';
  
  readonly supportedLanguages: LanguageOption[] = [
    { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧' },
    { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', flag: '🇮🇳' },
    { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳' }
  ];

  // Reactive signal for current language
  currentLang = signal<SupportedLanguage>(this.getInitialLanguage());

  private translations: Record<SupportedLanguage, Record<string, string>> = {
    en: {
      // Navigation
      'nav.brand': 'LumaRail',
      'nav.tagline': 'A Smarter Way to Travel',
      'nav.home': 'Home',
      'nav.search': 'Train Search',
      'nav.bookings': 'My Bookings',
      'nav.pnr': 'PNR Status',
      'nav.login': 'Sign In',
      'nav.register': 'Register',
      'nav.logout': 'Sign Out',
      'nav.welcome': 'Welcome',

      // Hero Section
      'hero.badge': 'LUMARAIL EXPRESS NETWORK',
      'hero.title_p1': 'A Smarter Way to',
      'hero.title_highlight': 'Travel by Rail',
      'hero.subtitle': 'Experience smooth, delightful railway booking with live telemetry, guaranteed berth allocations, and elegant digital boarding passes.',
      'hero.explore_btn': 'Search Available Trains',
      'hero.learn_more': 'Explore Scenic Routes',
      'hero.stat_punctuality': 'On-Time Precision',
      'hero.stat_routes': 'Direct Express Corridors',
      'hero.stat_rating': 'Passenger Satisfaction',

      // Quick Search Widget
      'search.widget_title': 'Find Your Train Journey',
      'search.from_station': 'Origin Station',
      'search.to_station': 'Destination Station',
      'search.select_from': 'Select Origin',
      'search.select_to': 'Select Destination',
      'search.journey_date': 'Travel Date',
      'search.travel_class': 'Travel Class',
      'search.all_classes': 'All Travel Classes',
      'search.btn': 'Search Available Trains',
      'search.same_station_error': 'Source and destination stations cannot be the same.',
      'search.date_required': 'Please select a valid future journey date.',
      'search.swap_stations': 'Swap Origin & Destination',
      'search.results_count': 'Trains Operating on this Route',
      'search.no_trains': 'No trains found for this route. Try swapping stations or selecting a different date.',
      'search.filter_all': 'All Types',

      // Train Card & Classes
      'train.train_no': 'Train No.',
      'train.duration': 'Duration',
      'train.halts': 'Halts',
      'train.view_route': 'Route Details',
      'train.departure': 'Departure',
      'train.arrival': 'Arrival',
      'train.available': 'AVAILABLE',
      'train.rac': 'RAC',
      'train.wl': 'WAITLIST',
      'train.fare': 'Fare',
      'train.book_now': 'Select & Book',
      'train.sl': 'Sleeper (SL)',
      'train.3a': 'AC 3-Tier (3A)',
      'train.2a': 'AC 2-Tier (2A)',
      'train.1a': 'First AC / Exec (1A)',
      'train.catering_included': 'Gourmet Meals Included',
      'train.runs_daily': 'Operates All Days',

      // Booking Page
      'booking.title': 'Complete Your Journey Reservation',
      'booking.subtitle': 'Review your itinerary and add passenger credentials.',
      'booking.train_details': 'Itinerary Summary',
      'booking.passenger_details': 'Passenger Credentials',
      'booking.add_passenger': '+ Add Another Passenger',
      'booking.remove_passenger': 'Remove',
      'booking.passenger_num': 'Passenger',
      'booking.full_name': 'Full Legal Name',
      'booking.name_placeholder': 'e.g. Aditi Sharma',
      'booking.age': 'Age',
      'booking.gender': 'Gender',
      'booking.gender_male': 'Male',
      'booking.gender_female': 'Female',
      'booking.gender_other': 'Other',
      'booking.berth_pref': 'Berth Preference',
      'booking.pref_no': 'No Preference',
      'booking.pref_lower': 'Lower Berth (LB)',
      'booking.pref_middle': 'Middle Berth (MB)',
      'booking.pref_upper': 'Upper Berth (UB)',
      'booking.pref_side_lower': 'Side Lower (SL)',
      'booking.pref_side_upper': 'Side Upper (SU)',
      'booking.pref_window': 'Window Seat (W)',
      'booking.contact_details': 'Contact Information for E-Ticket Delivery',
      'booking.phone': 'Mobile Number (10 digits)',
      'booking.email': 'Email Address',
      'booking.fare_summary': 'Fare Breakdown',
      'booking.base_fare': 'Base Passenger Fare',
      'booking.res_charge': 'Reservation & Surcharge',
      'booking.gst': 'Goods & Services Tax (GST 5%)',
      'booking.total_amount': 'Total Amount Payable',
      'booking.confirm_btn': 'Confirm & Generate E-Ticket',
      'booking.max_passengers_notice': 'Maximum 6 passengers allowed per single reservation ticket.',
      'booking.success_title': 'Reservation Confirmed Successfully!',
      'booking.success_pnr': 'Your Unique 10-Digit PNR:',
      'booking.view_pass': 'View Boarding Pass in My Bookings',
      'booking.print_ticket': 'Print E-Ticket',

      // My Bookings Page
      'my_bookings.title': 'My Reserved Tickets',
      'my_bookings.subtitle': 'Manage your upcoming journeys, inspect boarding passes, or initiate cancellations.',
      'my_bookings.no_tickets': 'No Reservations Found',
      'my_bookings.no_tickets_desc': 'You have not booked any journeys yet. Explore our premier routes and reserve your ticket today.',
      'my_bookings.book_now': 'Browse Scenic Trains',
      'my_bookings.pnr_label': 'PNR NUMBER',
      'my_bookings.status_confirmed': 'CONFIRMED',
      'my_bookings.status_cancelled': 'CANCELLED',
      'my_bookings.status_rac': 'RAC (RESERVATION AGAINST CANCELLATION)',
      'my_bookings.cancel_ticket': 'Cancel Ticket',
      'my_bookings.print_pass': 'Print Boarding Pass',
      'my_bookings.cancel_confirm_title': 'Confirm Ticket Cancellation',
      'my_bookings.cancel_confirm_msg': 'Are you sure you wish to cancel ticket with PNR',
      'my_bookings.refund_est': 'Refund will be processed back to original source after standard cancellation charges (₹120/passenger).',
      'my_bookings.cancel_proceed': 'Yes, Cancel Reservation',
      'my_bookings.cancel_abort': 'Keep My Ticket',

      // PNR Status Page
      'pnr.title': 'Live PNR Telemetry & Status Check',
      'pnr.subtitle': 'Instantly retrieve reservation verification, coach allocation, berth assignment, and charting status.',
      'pnr.input_label': 'Enter 10-Digit PNR Number',
      'pnr.placeholder': 'e.g. LUM-8924-X91',
      'pnr.check_btn': 'Check Live Status',
      'pnr.quick_samples': 'Or click a sample test PNR below to verify instantly:',
      'pnr.chart_status': 'Chart Preparation Status',
      'pnr.chart_prepared': 'CHART PREPARED',
      'pnr.chart_not_prepared': 'CHART NOT PREPARED (Finalizes 4 hours prior to departure)',
      'pnr.booking_status': 'Current Booking Status',
      'pnr.not_found_title': 'PNR Number Not Found',
      'pnr.not_found_desc': 'No reservation matching this PNR could be found in the system. Please verify the code or check My Bookings.',
      'pnr.coach_seat': 'Coach & Seat Details',
      'pnr.passenger_name': 'Passenger',
      'pnr.assigned_berth': 'Berth / Seat',

      // Auth (Login / Register)
      'auth.login_title': 'Welcome Back to LumaRail',
      'auth.login_sub': 'Sign in to access your itinerary records, saved passengers, and instant checkouts.',
      'auth.register_title': 'Create a LumaRail Traveler Account',
      'auth.register_sub': 'Join India’s smartest rail booking platform in under a minute.',
      'auth.name': 'Full Name',
      'auth.email': 'Email Address',
      'auth.phone': 'Mobile Phone',
      'auth.password': 'Password',
      'auth.confirm_password': 'Confirm Password',
      'auth.login_btn': 'Sign In',
      'auth.register_btn': 'Create Account',
      'auth.no_account': "Don't have an account?",
      'auth.have_account': 'Already registered?',
      'auth.demo_btn': 'One-Click Student Demo Login',
      'auth.password_mismatch': 'Passwords do not match.',
      'auth.email_invalid': 'Please enter a valid email address.',
      'auth.phone_invalid': 'Please enter a valid 10-digit mobile number.',
      'auth.password_short': 'Password must contain at least 6 characters.',
      'auth.login_failed': 'Invalid email or password. Please try again or use the demo login.',
      'auth.user_exists': 'An account with this email address already exists.',
      'auth.reg_success': 'Account created successfully! Welcome to LumaRail.',
      'auth.login_success': 'Welcome back to LumaRail! You have successfully signed in.',
      'auth.logout_success': 'You have been signed out safely.',

      // Features & Showcase
      'feat.title': 'A Fresh Approach to Rail Travel',
      'feat.subtitle': 'Designed from first principles to replace outdated systems with simplicity, warmth, and intuitive design.',
      'feat.1_title': 'Fresh & Minimal Interface',
      'feat.1_desc': 'Clean typography, calm pastel palettes, and ergonomic layout designed for total ease.',
      'feat.2_title': 'Starlink Satellite Rail Link',
      'feat.2_desc': 'Continuous ultra-low latency satellite internet connectivity across tunnels and rural corridors.',
      'feat.3_title': 'Chef-Crafted Regional Dining',
      'feat.3_desc': 'Regional Indian delicacies and wholesome light meals freshly plated to your seat.',
      'feat.4_title': 'Zero-Lag Instant Checkout',
      'feat.4_desc': 'Fast passenger form, instant berth allocation algorithm, and local telemetry storage.',

      // Footer
      'footer.desc': 'LumaRail – A Smarter Way to Travel. A modern railway reservation system built with Angular Standalone components, Reactive Forms, LocalStorage, and internationalization.',
      'footer.quick_links': 'Navigation',
      'footer.popular_corridors': 'Signature Corridors',
      'footer.academic_note': 'Academic Project Showcase: Built with Angular 19, TypeScript, Reactive Forms, LocalStorage, i18n & l10n.',
      'footer.rights': 'All rights reserved. LumaRail – A Smarter Way to Travel.'
    },

    te: {
      // Navigation (తెలుగు)
      'nav.brand': 'లుమారైల్',
      'nav.tagline': 'ప్రయాణానికి తెలివైన మార్గం',
      'nav.home': 'హోమ్',
      'nav.search': 'రైలు శోధన',
      'nav.bookings': 'నా బుకింగ్స్',
      'nav.pnr': 'PNR స్థితి',
      'nav.login': 'లాగిన్',
      'nav.register': 'రిజిస్టర్',
      'nav.logout': 'లాగౌట్',
      'nav.welcome': 'స్వాగతం',

      // Hero Section
      'hero.badge': 'లుమారైల్ ఎక్స్‌ప్రెస్ నెట్‌వర్క్',
      'hero.title_p1': 'రైలు ప్రయాణానికి ఒక',
      'hero.title_highlight': 'తెలివైన మార్గం',
      'hero.subtitle': 'లైవ్ ట్రాకింగ్, ఖచ్చితమైన బెర్త్ కేటాయింపు మరియు డిజిటల్ బోర్డింగ్ పాస్‌లతో అతుకులు లేని రైలు బుకింగ్ అనుభవాన్ని పొందండి.',
      'hero.explore_btn': 'అందుబాటులో ఉన్న రైళ్లను శోధించండి',
      'hero.learn_more': 'ప్రముఖ మార్గాలు చూడండి',
      'hero.stat_punctuality': 'సమయపాలన ఖచ్చితత్వం',
      'hero.stat_routes': 'ప్రత్యక్ష ఎక్స్‌ప్రెస్ మార్గాలు',
      'hero.stat_rating': 'ప్రయాణీకుల సంతృప్తి',

      // Quick Search Widget
      'search.widget_title': 'మీ ప్రయాణాన్ని ప్లాన్ చేసుకోండి',
      'search.from_station': 'బయలుదేరే స్టేషన్',
      'search.to_station': 'చేరుకునే స్టేషన్',
      'search.select_from': 'స్టేషన్ ఎంచుకోండి',
      'search.select_to': 'గమ్యస్థానం ఎంచుకోండి',
      'search.journey_date': 'ప్రయాణ తేదీ',
      'search.travel_class': 'ప్రయాణ తరగతి',
      'search.all_classes': 'అన్ని తరగతులు',
      'search.btn': 'అందుబాటులో ఉన్న రైళ్లను శోధించండి',
      'search.same_station_error': 'ప్రారంభ మరియు గమ్యస్థాన స్టేషన్లు ఒకేలా ఉండకూడదు.',
      'search.date_required': 'దయచేసి సరైన ప్రయాణ తేదీని ఎంచుకోండి.',
      'search.swap_stations': 'స్టేషన్లను మార్చండి',
      'search.results_count': 'ఈ మార్గంలో నడిచే రైళ్లు',
      'search.no_trains': 'ఈ మార్గంలో రైళ్లు కనుగొనబడలేదు. వేరొక తేదీని ప్రయత్నించండి.',
      'search.filter_all': 'అన్ని రకాలు',

      // Train Card & Classes
      'train.train_no': 'రైలు సంఖ్య',
      'train.duration': 'ప్రయాణ సమయం',
      'train.halts': 'స్టాప్‌లు',
      'train.view_route': 'రైలు మార్గం వివరాలు',
      'train.departure': 'బయలుదేరు సమయం',
      'train.arrival': 'చేరుకునే సమయం',
      'train.available': 'అందుబాటులో ఉన్నాయి',
      'train.rac': 'RAC',
      'train.wl': 'వెయిట్‌లిస్ట్',
      'train.fare': 'ధర',
      'train.book_now': 'ఎంచుకొని బుక్ చేయండి',
      'train.sl': 'స్లీపర్ (SL)',
      'train.3a': 'AC 3-టైర్ (3A)',
      'train.2a': 'AC 2-టైర్ (2A)',
      'train.1a': 'ఫస్ట్ AC / ఎగ్జిక్యూటివ్ (1A)',
      'train.catering_included': 'రుచికరమైన భోజనం ఉచితం',
      'train.runs_daily': 'రోజూ నడుస్తుంది',

      // Booking Page
      'booking.title': 'మీ రైలు టికెట్ రిజర్వేషన్ పూర్తి చేయండి',
      'booking.subtitle': 'ప్రయాణ వివరాలను సమీక్షించండి మరియు ప్రయాణీకుల సమాచారాన్ని నమోదు చేయండి.',
      'booking.train_details': 'ప్రయాణ సారాంశం',
      'booking.passenger_details': 'ప్రయాణీకుల వివరాలు',
      'booking.add_passenger': '+ మరొక ప్రయాణీకుడిని జోడించండి',
      'booking.remove_passenger': 'తొలగించు',
      'booking.passenger_num': 'ప్రయాణీకుడు',
      'booking.full_name': 'పూర్తి పేరు',
      'booking.name_placeholder': 'ఉదా: అఖిల్ వర్మ',
      'booking.age': 'వయస్సు',
      'booking.gender': 'లింగం',
      'booking.gender_male': 'పురుషుడు',
      'booking.gender_female': 'స్త్రీ',
      'booking.gender_other': 'ఇతర',
      'booking.berth_pref': 'బెర్త్ ప్రాధాన్యత',
      'booking.pref_no': 'ఏ ప్రాధాన్యత లేదు',
      'booking.pref_lower': 'లోయర్ బెర్త్ (LB)',
      'booking.pref_middle': 'మిడిల్ బెర్త్ (MB)',
      'booking.pref_upper': 'అప్పర్ బెర్త్ (UB)',
      'booking.pref_side_lower': 'సైడ్ లోయర్ (SL)',
      'booking.pref_side_upper': 'సైడ్ అప్పర్ (SU)',
      'booking.pref_window': 'కిటికీ సీటు (W)',
      'booking.contact_details': 'టికెట్ డెలివరీ కోసం సంప్రదింపు సమాచారం',
      'booking.phone': 'మొబైల్ నంబర్ (10 అంకెలు)',
      'booking.email': 'ఈమెయిల్ చిరునామా',
      'booking.fare_summary': 'టికెట్ ఛార్జీల వివరాలు',
      'booking.base_fare': 'ప్రాథమిక ఛార్జీ',
      'booking.res_charge': 'రిజర్వేషన్ & రుసుము',
      'booking.gst': 'GST పన్ను (5%)',
      'booking.total_amount': 'మొత్తం చెల్లించవలసిన మొత్తం',
      'booking.confirm_btn': 'ధృవీకరించి ఈ-టికెట్ పొందండి',
      'booking.max_passengers_notice': 'ఒకే రిజర్వేషన్‌లో గరిష్టంగా 6 మంది ప్రయాణీకులను మాత్రమే అనుమతిస్తారు.',
      'booking.success_title': 'రిజర్వేషన్ విజయవంతంగా పూర్తయింది!',
      'booking.success_pnr': 'మీ ప్రత్యేక 10-అంకెల PNR నంబర్:',
      'booking.view_pass': 'నా బుకింగ్స్‌లో బోర్డింగ్ పాస్ చూడండి',
      'booking.print_ticket': 'టికెట్ ప్రింట్ చేయండి',

      // My Bookings Page
      'my_bookings.title': 'నా రిజర్వుడ్ టికెట్లు',
      'my_bookings.subtitle': 'మీ రాబోయే ప్రయాణాలను నిర్వహించండి, బోర్డింగ్ పాస్‌లను చూడండి లేదా రద్దు చేసుకోండి.',
      'my_bookings.no_tickets': 'బుకింగ్‌లు ఏవీ లేవు',
      'my_bookings.no_tickets_desc': 'మీరు ఇంకా ఎటువంటి ప్రయాణాన్ని బుక్ చేసుకోలేదు. ఇప్పుడే రైళ్లను శోధించి టికెట్ బుక్ చేసుకోండి.',
      'my_bookings.book_now': 'రైళ్లను చూడండి',
      'my_bookings.pnr_label': 'PNR సంఖ్య',
      'my_bookings.status_confirmed': 'ధృవీకరించబడింది (CONFIRMED)',
      'my_bookings.status_cancelled': 'రద్దు చేయబడింది (CANCELLED)',
      'my_bookings.status_rac': 'RAC (రద్దుకు వ్యతిరేకంగా రిజర్వేషన్)',
      'my_bookings.cancel_ticket': 'టికెట్ రద్దు చేయండి',
      'my_bookings.print_pass': 'బోర్డింగ్ పాస్ ప్రింట్ చేయండి',
      'my_bookings.cancel_confirm_title': 'టికెట్ రద్దును ధృవీకరించండి',
      'my_bookings.cancel_confirm_msg': 'మీరు ఖచ్చితంగా ఈ PNR టికెట్‌ను రద్దు చేయాలనుకుంటున్నారా?',
      'my_bookings.refund_est': 'సాధారణ రద్దు రుసుము (ప్రయాణీకుడికి ₹120) మినహాయించిన తర్వాత మిగిలిన రీఫండ్ ఖాతాకు జమ చేయబడుతుంది.',
      'my_bookings.cancel_proceed': 'అవును, టికెట్ రద్దు చేయండి',
      'my_bookings.cancel_abort': 'నా టికెట్‌ను ఉంచుకోండి',

      // PNR Status Page
      'pnr.title': 'ప్రత్యక్ష PNR స్థితి పరిశీలన',
      'pnr.subtitle': 'రిజర్వేషన్ ధృవీకరణ, కోచ్ కేటాయింపు, బెర్త్ మరియు చార్ట్ స్థితిని వెంటనే తనిఖీ చేయండి.',
      'pnr.input_label': '10-అంకెల PNR నంబర్‌ను నమోదు చేయండి',
      'pnr.placeholder': 'ఉదా: LUM-8924-X91',
      'pnr.check_btn': 'స్థితిని తనిఖీ చేయండి',
      'pnr.quick_samples': 'లేదా పరీక్షించడానికి క్రింది నమూనా PNR పై క్లిక్ చేయండి:',
      'pnr.chart_status': 'చార్ట్ తయారీ స్థితి',
      'pnr.chart_prepared': 'చార్ట్ సిద్ధమైంది (CHART PREPARED)',
      'pnr.chart_not_prepared': 'చార్ట్ ఇంకా సిద్ధం కాలేదు (బయలుదేరడానికి 4 గంటల ముందు సిద్ధమవుతుంది)',
      'pnr.booking_status': 'ప్రస్తుత బుకింగ్ స్థితి',
      'pnr.not_found_title': 'PNR నంబర్ కనుగొనబడలేదు',
      'pnr.not_found_desc': 'ఈ PNR తో సరిపోలే ఎటువంటి బుకింగ్ కనుగొనబడలేదు. దయచేసి సంఖ్యను తనిఖీ చేయండి.',
      'pnr.coach_seat': 'కోచ్ & సీటు వివరాలు',
      'pnr.passenger_name': 'ప్రయాణీకుడు',
      'pnr.assigned_berth': 'కేటాయించిన బెర్త్ / సీటు',

      // Auth (Login / Register)
      'auth.login_title': 'లుమారైల్‌కి తిరిగి స్వాగతం',
      'auth.login_sub': 'మీ ప్రయాణ రికార్డులు మరియు బుకింగ్స్ చూడటానికి లాగిన్ అవ్వండి.',
      'auth.register_title': 'కొత్త లుమారైల్ ఖాతాను సృష్టించండి',
      'auth.register_sub': 'భారతదేశపు అత్యుత్తమ రైలు నెట్‌వర్క్‌లో చేరండి.',
      'auth.name': 'పూర్తి పేరు',
      'auth.email': 'ఈమెయిల్ చిరునామా',
      'auth.phone': 'మొబైల్ ఫోన్',
      'auth.password': 'పాస్‌వర్డ్',
      'auth.confirm_password': 'పాస్‌వర్డ్‌ని నిర్ధారించండి',
      'auth.login_btn': 'లాగిన్ అవ్వండి',
      'auth.register_btn': 'ఖాతాను సృష్టించండి',
      'auth.no_account': 'ఖాతా లేదా?',
      'auth.have_account': 'ఇప్పటికే ఖాతా ఉందా?',
      'auth.demo_btn': 'ఒకే క్లిక్‌తో విద్యార్థి డెమో లాగిన్',
      'auth.password_mismatch': 'పాస్‌వర్డ్‌లు సరిపోలడం లేదు.',
      'auth.email_invalid': 'సరైన ఈమెయిల్ చిరునామాను నమోదు చేయండి.',
      'auth.phone_invalid': 'సరైన 10 అంకెల మొబైల్ నంబర్‌ను నమోదు చేయండి.',
      'auth.password_short': 'పాస్‌వర్డ్ కనీసం 6 అక్షరాలు ఉండాలి.',
      'auth.login_failed': 'ఈమెయిల్ లేదా పాస్‌వర్డ్ సరైనది కాదు.',
      'auth.user_exists': 'ఈ ఈమెయిల్ చిరునామాతో ఇప్పటికే ఖాతా ఉంది.',
      'auth.reg_success': 'ఖాతా విజయవంతంగా సృష్టించబడింది! లుమారైల్‌కి స్వాగతం.',
      'auth.login_success': 'తిరిగి స్వాగతం! మీరు విజయవంతంగా లాగిన్ అయ్యారు.',
      'auth.logout_success': 'మీరు సురక్షితంగా లాగౌట్ అయ్యారు.',

      // Features & Showcase
      'feat.title': 'రైలు ప్రయాణానికి సరికొత్త రూపు',
      'feat.subtitle': 'వేగం, ఆహ్లాదకరమైన డిజైన్ మరియు స్వచ్ఛమైన సౌకర్యంతో నిర్మించబడింది.',
      'feat.1_title': 'స్వచ్ఛమైన మరియు సరళమైన డిజైన్',
      'feat.1_desc': 'కళ్ళకు హాయినిచ్చే రంగులు మరియు సులభతరమైన నావిగేషన్.',
      'feat.2_title': 'హై-స్పీడ్ శాటిలైట్ ఇంటర్నెట్',
      'feat.2_desc': 'ప్రయాణమంతా వేగవంతమైన శాటిలైట్ వైఫై సదుపాయం.',
      'feat.3_title': 'రుచికరమైన స్వచ్ఛమైన భోజనం',
      'feat.3_desc': 'మీ సీటు వద్దకే ఫ్రెష్‌గా అందించబడే ప్రసిద్ధ భారతీయ వంటకాలు.',
      'feat.4_title': 'తక్షణ బుకింగ్ మరియు సీటు కేటాయింపు',
      'feat.4_desc': 'ఎటువంటి ఆటంకం లేని వేగవంతమైన బుకింగ్ మరియు లోకల్ PNR వ్యవస్థ.',

      // Footer
      'footer.desc': 'లుమారైల్ – ప్రయాణానికి తెలివైన మార్గం. ఆధునిక Angular మరియు UI/UX డిజైన్‌తో రూపొందించబడిన ప్రత్యేక అకడమిక్ రైల్వే రిజర్వేషన్ ప్లాట్‌ఫామ్.',
      'footer.quick_links': 'లింకులు',
      'footer.popular_corridors': 'ప్రసిద్ధ మార్గాలు',
      'footer.academic_note': 'అకడమిక్ ప్రాజెక్ట్: Angular 19, TypeScript, Reactive Forms, LocalStorage, i18n & l10n తో నిర్మించబడింది.',
      'footer.rights': 'సర్వ హక్కులు ప్రత్యేకించబడ్డాయి. లుమారైల్ – ప్రయాణానికి తెలివైన మార్గం.'
    },

    hi: {
      // Navigation (हिन्दी)
      'nav.brand': 'लुमारेल',
      'nav.tagline': 'यात्रा का एक समझदार तरीका',
      'nav.home': 'होम',
      'nav.search': 'ट्रेन खोजें',
      'nav.bookings': 'मेरी बुकिंग्स',
      'nav.pnr': 'पीएनआर स्थिति',
      'nav.login': 'लॉग इन',
      'nav.register': 'पंजीकरण',
      'nav.logout': 'लॉग आउट',
      'nav.welcome': 'स्वागत है',

      // Hero Section
      'hero.badge': 'लुमारेल एक्सप्रेस नेटवर्क',
      'hero.title_p1': 'ट्रेन यात्रा का एक',
      'hero.title_highlight': 'समझदार तरीका',
      'hero.subtitle': 'लाइव टेलीमेट्री, कन्फर्म्ड बर्थ आवंटन और सुरुचिपूर्ण डिजिटल बोर्डिंग पास के साथ सहज रेल आरक्षण का अनुभव करें।',
      'hero.explore_btn': 'उपलब्ध ट्रेनें खोजें',
      'hero.learn_more': 'प्रमुख रूट देखें',
      'hero.stat_punctuality': 'समय की पाबंदी',
      'hero.stat_routes': 'प्रत्यक्ष एक्सप्रेस कॉरिडोर',
      'hero.stat_rating': 'यात्री संतुष्टि',

      // Quick Search Widget
      'search.widget_title': 'अपनी यात्रा की योजना बनाएं',
      'search.from_station': 'प्रस्थान स्टेशन',
      'search.to_station': 'गंतव्य स्टेशन',
      'search.select_from': 'प्रस्थान स्टेशन चुनें',
      'search.select_to': 'गंतव्य स्टेशन चुनें',
      'search.journey_date': 'यात्रा की तारीख',
      'search.travel_class': 'यात्रा श्रेणी',
      'search.all_classes': 'सभी श्रेणियां',
      'search.btn': 'उपलब्ध ट्रेनें खोजें',
      'search.same_station_error': 'प्रस्थान और गंतव्य स्टेशन समान नहीं हो सकते।',
      'search.date_required': 'कृपया वैध भविष्य की यात्रा तिथि चुनें।',
      'search.swap_stations': 'स्टेशन बदलें',
      'search.results_count': 'इस रूट पर चलने वाली ट्रेनें',
      'search.no_trains': 'इस रूट के लिए कोई ट्रेन नहीं मिली। कृपया कोई अन्य तारीख या स्टेशन चुनकर देखें।',
      'search.filter_all': 'सभी प्रकार',

      // Train Card & Classes
      'train.train_no': 'ट्रेन संख्या',
      'train.duration': 'यात्रा अवधि',
      'train.halts': 'स्टॉप',
      'train.view_route': 'रूट विवरण',
      'train.departure': 'प्रस्थान',
      'train.arrival': 'आगमन',
      'train.available': 'उपलब्ध',
      'train.rac': 'आरएसी (RAC)',
      'train.wl': 'प्रतीक्षा सूची (WL)',
      'train.fare': 'किराया',
      'train.book_now': 'चुनें और बुक करें',
      'train.sl': 'स्लीपर (SL)',
      'train.3a': 'एसी 3-टियर (3A)',
      'train.2a': 'एसी 2-टियर (2A)',
      'train.1a': 'प्रथम एसी / एग्जीक्यूटिव (1A)',
      'train.catering_included': 'स्वादिष्ट भोजन शामिल',
      'train.runs_daily': 'प्रतिदिन संचालित',

      // Booking Page
      'booking.title': 'अपना यात्रा आरक्षण पूरा करें',
      'booking.subtitle': 'यात्रा विवरण की समीक्षा करें और यात्री जानकारी दर्ज करें।',
      'booking.train_details': 'यात्रा सारांश',
      'booking.passenger_details': 'यात्री विवरण',
      'booking.add_passenger': '+ अन्य यात्री जोड़ें',
      'booking.remove_passenger': 'हटाएं',
      'booking.passenger_num': 'यात्री',
      'booking.full_name': 'पूरा कानूनी नाम',
      'booking.name_placeholder': 'उदा. राहुल शर्मा',
      'booking.age': 'आयु',
      'booking.gender': 'लिंग',
      'booking.gender_male': 'पुरुष',
      'booking.gender_female': 'महिला',
      'booking.gender_other': 'अन्य',
      'booking.berth_pref': 'बर्थ प्राथमिकता',
      'booking.pref_no': 'कोई प्राथमिकता नहीं',
      'booking.pref_lower': 'निचला बर्थ (LB)',
      'booking.pref_middle': 'मध्यम बर्थ (MB)',
      'booking.pref_upper': 'ऊपरी बर्थ (UB)',
      'booking.pref_side_lower': 'साइड लोअर (SL)',
      'booking.pref_side_upper': 'साइड अपर (SU)',
      'booking.pref_window': 'विंडो सीट (W)',
      'booking.contact_details': 'ई-टिकट के लिए संपर्क विवरण',
      'booking.phone': 'मोबाइल नंबर (10 अंक)',
      'booking.email': 'ईमेल पता',
      'booking.fare_summary': 'किराया विवरण',
      'booking.base_fare': 'मूल यात्री किराया',
      'booking.res_charge': 'आरक्षण शुल्क',
      'booking.gst': 'जीएसटी कर (5%)',
      'booking.total_amount': 'कुल देय राशि',
      'booking.confirm_btn': 'पुष्टि करें और ई-टिकट प्राप्त करें',
      'booking.max_passengers_notice': 'एक आरक्षण में अधिकतम 6 यात्रियों की अनुमति है।',
      'booking.success_title': 'आरक्षण सफलतापूर्वक पुष्टि हो गया!',
      'booking.success_pnr': 'आपका 10-अंकीय पीएनआर नंबर:',
      'booking.view_pass': 'मेरी बुकिंग्स में बोर्डिंग पास देखें',
      'booking.print_ticket': 'टिकट प्रिंट करें',

      // My Bookings Page
      'my_bookings.title': 'मेरे आरक्षित टिकट',
      'my_bookings.subtitle': 'अपनी आगामी यात्राओं को प्रबंधित करें, बोर्डिंग पास देखें या टिकट रद्द करें।',
      'my_bookings.no_tickets': 'कोई आरक्षण नहीं मिला',
      'my_bookings.no_tickets_desc': 'आपने अभी तक कोई यात्रा बुक नहीं की है। हमारी ट्रेनें देखें और आज ही टिकट बुक करें।',
      'my_bookings.book_now': 'ट्रेनें देखें',
      'my_bookings.pnr_label': 'पीएनआर संख्या',
      'my_bookings.status_confirmed': 'पुष्ट (CONFIRMED)',
      'my_bookings.status_cancelled': 'रद्द (CANCELLED)',
      'my_bookings.status_rac': 'आरएसी (RAC)',
      'my_bookings.cancel_ticket': 'टिकट रद्द करें',
      'my_bookings.print_pass': 'बोर्डिंग पास प्रिंट करें',
      'my_bookings.cancel_confirm_title': 'टिकट रद्दीकरण की पुष्टि करें',
      'my_bookings.cancel_confirm_msg': 'क्या आप वाकई इस पीएनआर वाले टिकट को रद्द करना चाहते हैं?',
      'my_bookings.refund_est': 'मानक रद्दीकरण शुल्क (₹120/यात्री) काटने के बाद शेष रिफंड आपके खाते में भेज दिया जाएगा।',
      'my_bookings.cancel_proceed': 'हाँ, आरक्षण रद्द करें',
      'my_bookings.cancel_abort': 'टिकट बनाए रखें',

      // PNR Status Page
      'pnr.title': 'लाइव पीएनआर स्थिति जांच',
      'pnr.subtitle': 'आरक्षण सत्यापन, कोच आवंटन, बर्थ और चार्ट की स्थिति तुरंत जांचें।',
      'pnr.input_label': '10-अंकीय पीएनआर नंबर दर्ज करें',
      'pnr.placeholder': 'उदा. LUM-8924-X91',
      'pnr.check_btn': 'स्थिति जांचें',
      'pnr.quick_samples': 'या तुरंत परीक्षण के लिए नीचे दिए गए नमूना पीएनआर पर क्लिक करें:',
      'pnr.chart_status': 'चार्ट तैयार स्थिति',
      'pnr.chart_prepared': 'चार्ट तैयार है (CHART PREPARED)',
      'pnr.chart_not_prepared': 'चार्ट अभी तैयार नहीं हुआ (प्रस्थान से 4 घंटे पहले तैयार होगा)',
      'pnr.booking_status': 'वर्तमान बुकिंग स्थिति',
      'pnr.not_found_title': 'पीएनआर नंबर नहीं मिला',
      'pnr.not_found_desc': 'इस पीएनआर से मेल खाने वाला कोई आरक्षण नहीं मिला। कृपया नंबर की जांच करें।',
      'pnr.coach_seat': 'कोच और सीट विवरण',
      'pnr.passenger_name': 'यात्री',
      'pnr.assigned_berth': 'आवंटित बर्थ / सीट',

      // Auth (Login / Register)
      'auth.login_title': 'लुमारेल में पुनः स्वागत है',
      'auth.login_sub': 'अपने यात्रा रिकॉर्ड और सुरक्षित चेकआउट के लिए साइन इन करें।',
      'auth.register_title': 'नया लुमारेल खाता बनाएं',
      'auth.register_sub': 'भारत के सबसे आधुनिक हाई-स्पीड रेल नेटवर्क से जुड़ें।',
      'auth.name': 'पूरा नाम',
      'auth.email': 'ईमेल पता',
      'auth.phone': 'मोबाइल फोन',
      'auth.password': 'पासवर्ड',
      'auth.confirm_password': 'पासवर्ड की पुष्टि करें',
      'auth.login_btn': 'साइन इन करें',
      'auth.register_btn': 'खाता बनाएं',
      'auth.no_account': 'खाता नहीं है?',
      'auth.have_account': 'पहले से पंजीकृत हैं?',
      'auth.demo_btn': 'एक-क्लिक छात्र डेमो लॉगिन',
      'auth.password_mismatch': 'पासवर्ड मेल नहीं खा रहे हैं।',
      'auth.email_invalid': 'कृपया एक वैध ईमेल पता दर्ज करें।',
      'auth.phone_invalid': 'कृपया 10 अंकों का वैध मोबाइल नंबर दर्ज करें।',
      'auth.password_short': 'पासवर्ड में कम से कम 6 अक्षर होने चाहिए।',
      'auth.login_failed': 'अमान्य ईमेल या पासवर्ड। कृपया पुनः प्रयास करें।',
      'auth.user_exists': 'इस ईमेल पते से पहले से एक खाता मौजूद है।',
      'auth.reg_success': 'खाता सफलतापूर्वक बनाया गया! लुमारेल में स्वागत है।',
      'auth.login_success': 'पुनः स्वागत है! आप सफलतापूर्वक साइन इन हो चुके हैं।',
      'auth.logout_success': 'आप सुरक्षित रूप से लॉग आउट हो गए हैं।',

      // Features & Showcase
      'feat.title': 'रेल यात्रा का एक नया और सुरुचिपूर्ण अनुभव',
      'feat.subtitle': 'अत्याधुनिक गति, हल्के पेस्टल रंगों और यात्री सुविधा के साथ निर्मित।',
      'feat.1_title': 'सरल और सुखद इंटरफ़ेस',
      'feat.1_desc': 'आंखों को भाने वाले रंग और सहज संचालन के साथ आधुनिक डिज़ाइन।',
      'feat.2_title': 'हाई-स्पीड स्टारलिंक इंटरनेट',
      'feat.2_desc': 'सुरंगों और दूरदराज के क्षेत्रों में भी निर्बाध उपग्रह वाई-फाई।',
      'feat.3_title': 'स्वादिष्ट और पौष्टिक भोजन',
      'feat.3_desc': 'आपकी सीट पर ताजा परोसा जाने वाला लजीज भारतीय भोजन।',
      'feat.4_title': 'तत्काल बुकिंग और सीट आवंटन',
      'feat.4_desc': 'बिना किसी परेशानी के त्वरित बुकिंग और रीयल-टाइम पीएनआर बहीखाता।',

      // Footer
      'footer.desc': 'लुमारेल – यात्रा का एक समझदार तरीका। एक आधुनिक रेलवे आरक्षण प्रणाली जो सरलता, गति और सुरुचिपूर्ण डिज़ाइन को जोड़ती है।',
      'footer.quick_links': 'त्वरित लिंक',
      'footer.popular_corridors': 'प्रमुख कॉरिडोर',
      'footer.academic_note': 'शैक्षणिक परियोजना: Angular 19, TypeScript, Reactive Forms, LocalStorage, i18n और l10n द्वारा निर्मित।',
      'footer.rights': 'सर्वाधिकार सुरक्षित। लुमारेल – यात्रा का एक समझदार तरीका।'
    }
  };

  private getInitialLanguage(): SupportedLanguage {
    const saved = localStorage.getItem(this.STORAGE_KEY) as SupportedLanguage;
    if (saved && (saved === 'en' || saved === 'te' || saved === 'hi')) {
      return saved;
    }
    return 'en';
  }

  setLanguage(lang: SupportedLanguage): void {
    this.currentLang.set(lang);
    localStorage.setItem(this.STORAGE_KEY, lang);
  }

  translate(key: string): string {
    const lang = this.currentLang();
    const table = this.translations[lang] || this.translations['en'];
    return table[key] || this.translations['en'][key] || key;
  }

  // l10n: Localization helpers for Regional Dates, Times, and Currency
  formatDate(dateInput: string | Date): string {
    if (!dateInput) return '';
    const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
    if (isNaN(date.getTime())) return String(dateInput);

    const lang = this.currentLang();
    const localeMap: Record<SupportedLanguage, string> = {
      en: 'en-IN',
      te: 'te-IN',
      hi: 'hi-IN'
    };
    const locale = localeMap[lang] || 'en-IN';

    return new Intl.DateTimeFormat(locale, {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    }).format(date);
  }

  formatCurrency(amount: number): string {
    const lang = this.currentLang();
    const localeMap: Record<SupportedLanguage, string> = {
      en: 'en-IN',
      te: 'te-IN',
      hi: 'hi-IN'
    };
    const locale = localeMap[lang] || 'en-IN';

    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  }
}
