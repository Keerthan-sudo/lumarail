export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  password?: string;
  createdAt: string;
}

export interface AuthSession {
  user: User;
  token: string;
  loginTime: string;
}
