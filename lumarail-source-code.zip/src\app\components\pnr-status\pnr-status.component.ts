import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { BookingService } from '../../services/booking.service';
import { I18nService } from '../../services/i18n.service';
import { NotificationService } from '../../services/notification.service';
import { Booking } from '../../models/booking.model';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-pnr-status',
  standalone: true,
  imports: [CommonModule, FormsModule, TranslatePipe],
  templateUrl: './pnr-status.component.html',
  styleUrl: './pnr-status.component.css'
})
export class PNRStatusComponent implements OnInit {
  pnrInput = '';
  searched = false;
  matchedBooking: Booking | null = null;
  errorMessage = '';

  // Quick evaluator sample PNRs
  samplePNRs = ['LUM-8924-X91', 'LUM-4102-K55'];

  constructor(
    public bookingService: BookingService,
    public i18nService: I18nService,
    private notificationService: NotificationService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      if (params['pnr']) {
        this.pnrInput = params['pnr'];
        this.checkPNR();
      }
    });
  }

  checkPNR(): void {
    if (!this.pnrInput.trim()) {
      this.errorMessage = 'Please enter a 10-digit PNR number.';
      this.matchedBooking = null;
      this.searched = false;
      return;
    }

    this.errorMessage = '';
    this.searched = true;

    const result = this.bookingService.getBookingByPNR(this.pnrInput);
    if (result) {
      this.matchedBooking = result;
      this.notificationService.success(`Live telemetry loaded for PNR: ${result.pnr}`, 'Record Verified');
    } else {
      this.matchedBooking = null;
    }
  }

  useSample(sample: string): void {
    this.pnrInput = sample;
    this.checkPNR();
  }

  printReport(): void {
    window.print();
  }
}
