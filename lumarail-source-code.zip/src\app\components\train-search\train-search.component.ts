import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { TrainService } from '../../services/train.service';
import { I18nService } from '../../services/i18n.service';
import { NotificationService } from '../../services/notification.service';
import { Station, Train, TrainClass } from '../../models/train.model';
import { TranslatePipe } from '../../pipes/translate.pipe';

@Component({
  selector: 'app-train-search',
  standalone: true,
  imports: [CommonModule, FormsModule, TranslatePipe],
  templateUrl: './train-search.component.html',
  styleUrl: './train-search.component.css'
})
export class TrainSearchComponent implements OnInit {
  stations: Station[] = [];
  trains: Train[] = [];

  // Filter Bar state
  fromCode = 'NDLS';
  toCode = 'BSB';
  journeyDate = '';
  selectedClass = 'ALL';
  filterType = 'ALL';
  errorMessage = '';

  minDate = '';

  constructor(
    public trainService: TrainService,
    public i18nService: I18nService,
    private notificationService: NotificationService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.stations = this.trainService.getStations();
    
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    this.minDate = new Date().toISOString().split('T')[0];
    this.journeyDate = tomorrow.toISOString().split('T')[0];

    // Read query params if present
    this.route.queryParams.subscribe(params => {
      if (params['from']) this.fromCode = params['from'];
      if (params['to']) this.toCode = params['to'];
      if (params['date']) this.journeyDate = params['date'];
      if (params['class']) this.selectedClass = params['class'];

      this.performSearch();
    });
  }

  performSearch(): void {
    if (!this.fromCode || !this.toCode) {
      this.errorMessage = 'Please select origin and destination stations.';
      return;
    }

    if (this.fromCode === this.toCode) {
      this.errorMessage = this.i18nService.translate('search.same_station_error');
      this.notificationService.warning(this.errorMessage);
      this.trains = [];
      return;
    }

    this.errorMessage = '';
    let results = this.trainService.searchTrains(this.fromCode, this.toCode, this.selectedClass);

    if (this.filterType !== 'ALL') {
      results = results.filter(t => t.trainType === this.filterType);
    }

    this.trains = results;
  }

  swapStations(): void {
    const temp = this.fromCode;
    this.fromCode = this.toCode;
    this.toCode = temp;
    this.performSearch();
  }

  onFilterChange(): void {
    this.performSearch();
  }

  proceedToBooking(train: Train, trainClass: TrainClass): void {
    this.router.navigate(['/booking', train.id, trainClass.code], {
      queryParams: {
        date: this.journeyDate
      }
    });
  }

  getFromStationName(): string {
    const s = this.trainService.getStationByCode(this.fromCode);
    return s ? `${s.city} (${s.code})` : this.fromCode;
  }

  getToStationName(): string {
    const s = this.trainService.getStationByCode(this.toCode);
    return s ? `${s.city} (${s.code})` : this.toCode;
  }
}
