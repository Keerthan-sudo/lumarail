import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { TrainSearchComponent } from './components/train-search/train-search.component';
import { BookingComponent } from './components/booking/booking.component';
import { MyBookingsComponent } from './components/my-bookings/my-bookings.component';
import { PNRStatusComponent } from './components/pnr-status/pnr-status.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { authGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', component: HomeComponent, title: 'LumaRail – A Smarter Way to Travel' },
  { path: 'search', component: TrainSearchComponent, title: 'Train Search & Availability — LumaRail' },
  { path: 'booking/:trainId/:classCode', component: BookingComponent, canActivate: [authGuard], title: 'Complete Booking — LumaRail' },
  { path: 'my-bookings', component: MyBookingsComponent, canActivate: [authGuard], title: 'My Bookings — LumaRail' },
  { path: 'pnr-status', component: PNRStatusComponent, title: 'PNR Telemetry Status — LumaRail' },
  { path: 'login', component: LoginComponent, title: 'Sign In — LumaRail' },
  { path: 'register', component: RegisterComponent, title: 'Register Account — LumaRail' },
  { path: '**', redirectTo: '' }
];
