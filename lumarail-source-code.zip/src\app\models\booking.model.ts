import { Station } from './train.model';

export type BerthPreference = 'Lower' | 'Middle' | 'Upper' | 'Side Lower' | 'Side Upper' | 'Window' | 'No Preference';

export interface PassengerDetail {
  id: string;
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  berthPreference: BerthPreference;
  assignedCoach?: string; // e.g. "B2"
  assignedSeat?: string;  // e.g. "24 (LB)"
  status: 'CONFIRMED' | 'RAC' | 'WL';
}

export interface FareBreakdown {
  baseFarePerPerson: number;
  passengerCount: number;
  subTotal: number;
  reservationFee: number;
  superfastCharge: number;
  gstAmount: number;
  totalFare: number;
}

export interface Booking {
  id: string;
  pnr: string;
  userId: string;
  userEmail: string;
  userName: string;
  userPhone: string;
  trainId: string;
  trainNumber: string;
  trainName: string;
  trainType: string;
  fromStation: Station;
  toStation: Station;
  journeyDate: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  selectedClass: 'SL' | '3A' | '2A' | '1A';
  className: string;
  passengers: PassengerDetail[];
  fareBreakdown: FareBreakdown;
  status: 'CONFIRMED' | 'RAC' | 'WL' | 'CANCELLED';
  chartStatus: 'CHART PREPARED' | 'CHART NOT PREPARED';
  bookingDate: string;
  cancellationDate?: string;
  refundAmount?: number;
}
